from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .model import (
    ARTIFACT_SCHEMA_VERSION,
    CLASS_NAMES,
    CONTRACT_VERSION,
    FEATURE_NAMES,
    feature_vector,
)


def _read_dataset(path: Path) -> tuple[list[list[float]], list[int], list[str]]:
    vectors: list[list[float]] = []
    labels: list[int] = []
    groups: list[str] = []
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        required = {
            "group_id",
            "scientific_name",
            "leaf_type",
            "occupancy",
            "height_mm",
            "height_ratio",
            "canopy_area_mm2",
            "green_fraction",
            "chlorotic_fraction",
            "necrotic_fraction",
            "coverage",
            "label",
        }
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError(f"dataset is missing columns: {', '.join(sorted(missing))}")
        for row in reader:
            if row["label"] not in CLASS_NAMES:
                raise ValueError(f"unsupported label: {row['label']}")
            features = {
                "occupancy": float(row["occupancy"]),
                "heightMm": float(row["height_mm"]),
                "heightRatio": float(row["height_ratio"]),
                "canopyAreaMm2": float(row["canopy_area_mm2"]),
                "greenFraction": float(row["green_fraction"]),
                "chloroticFraction": float(row["chlorotic_fraction"]),
                "necroticFraction": float(row["necrotic_fraction"]),
                "coverage": float(row["coverage"]),
            }
            vectors.append(feature_vector(features, row["scientific_name"], row["leaf_type"]))
            labels.append(CLASS_NAMES.index(row["label"]))
            groups.append(row["group_id"])
    if len(vectors) < len(CLASS_NAMES) * 4:
        raise ValueError("dataset is too small to train all classes")
    if set(labels) != set(range(len(CLASS_NAMES))):
        raise ValueError("dataset must contain every supported class")
    return vectors, labels, groups


def _validation_group(group: str) -> bool:
    digest = hashlib.sha256(group.encode("utf-8")).digest()
    return digest[0] % 5 == 0


def _standardization(vectors: list[list[float]]) -> tuple[list[float], list[float]]:
    means = [sum(row[index] for row in vectors) / len(vectors) for index in range(len(FEATURE_NAMES))]
    scales = []
    for index, mean in enumerate(means):
        variance = sum((row[index] - mean) ** 2 for row in vectors) / len(vectors)
        scales.append(max(math.sqrt(variance), 1e-8))
    return means, scales


def _standardize(
    vectors: list[list[float]], means: list[float], scales: list[float]
) -> list[list[float]]:
    return [
        [(value - mean) / scale for value, mean, scale in zip(row, means, scales, strict=True)]
        for row in vectors
    ]


def _softmax(logits: list[float], temperature: float = 1.0) -> list[float]:
    scaled = [value / temperature for value in logits]
    maximum = max(scaled)
    values = [math.exp(value - maximum) for value in scaled]
    total = sum(values)
    return [value / total for value in values]


def _train(
    vectors: list[list[float]],
    labels: list[int],
    epochs: int,
    learning_rate: float,
    l2: float,
) -> tuple[list[list[float]], list[float]]:
    class_count = len(CLASS_NAMES)
    feature_count = len(FEATURE_NAMES)
    weights = [[0.0] * feature_count for _ in range(class_count)]
    bias = [0.0] * class_count
    sample_count = len(vectors)
    for epoch in range(epochs):
        weight_gradient = [[0.0] * feature_count for _ in range(class_count)]
        bias_gradient = [0.0] * class_count
        for vector, label in zip(vectors, labels, strict=True):
            logits = [
                bias[class_index]
                + sum(
                    weights[class_index][feature_index] * vector[feature_index]
                    for feature_index in range(feature_count)
                )
                for class_index in range(class_count)
            ]
            probabilities = _softmax(logits)
            for class_index in range(class_count):
                error = probabilities[class_index] - (1.0 if class_index == label else 0.0)
                bias_gradient[class_index] += error
                for feature_index in range(feature_count):
                    weight_gradient[class_index][feature_index] += error * vector[feature_index]
        rate = learning_rate / (1 + epoch * 0.002)
        for class_index in range(class_count):
            bias[class_index] -= rate * bias_gradient[class_index] / sample_count
            for feature_index in range(feature_count):
                gradient = (
                    weight_gradient[class_index][feature_index] / sample_count
                    + l2 * weights[class_index][feature_index]
                )
                weights[class_index][feature_index] -= rate * gradient
    return weights, bias


def _logits(
    vectors: list[list[float]], weights: list[list[float]], bias: list[float]
) -> list[list[float]]:
    return [
        [
            class_bias + sum(weight * value for weight, value in zip(row, vector, strict=True))
            for row, class_bias in zip(weights, bias, strict=True)
        ]
        for vector in vectors
    ]


def _log_loss(logits: list[list[float]], labels: list[int], temperature: float) -> float:
    return -sum(
        math.log(max(_softmax(row, temperature)[label], 1e-12))
        for row, label in zip(logits, labels, strict=True)
    ) / len(labels)


def _metrics(
    logits: list[list[float]], labels: list[int], temperature: float
) -> dict[str, Any]:
    predictions = [
        max(range(len(CLASS_NAMES)), key=_softmax(row, temperature).__getitem__)
        for row in logits
    ]
    correct = sum(predicted == expected for predicted, expected in zip(predictions, labels, strict=True))
    per_class = {}
    for class_index, class_name in enumerate(CLASS_NAMES):
        positions = [index for index, label in enumerate(labels) if label == class_index]
        per_class[class_name] = round(
            sum(predictions[index] == class_index for index in positions) / len(positions), 6
        )
    return {
        "accuracy": round(correct / len(labels), 6),
        "logLoss": round(_log_loss(logits, labels, temperature), 6),
        "classAccuracy": per_class,
    }


def train_model(
    input_path: str | Path,
    output_path: str | Path,
    model_version: str,
    epochs: int = 500,
) -> dict[str, Any]:
    source = Path(input_path)
    vectors, labels, groups = _read_dataset(source)
    validation_mask = [_validation_group(group) for group in groups]
    if not any(validation_mask) or all(validation_mask):
        raise ValueError("group split did not produce both training and validation data")
    train_vectors = [row for row, validation in zip(vectors, validation_mask, strict=True) if not validation]
    train_labels = [label for label, validation in zip(labels, validation_mask, strict=True) if not validation]
    validation_vectors = [row for row, validation in zip(vectors, validation_mask, strict=True) if validation]
    validation_labels = [label for label, validation in zip(labels, validation_mask, strict=True) if validation]
    means, scales = _standardization(train_vectors)
    standardized_train = _standardize(train_vectors, means, scales)
    standardized_validation = _standardize(validation_vectors, means, scales)
    weights, bias = _train(
        standardized_train,
        train_labels,
        epochs=epochs,
        learning_rate=0.12,
        l2=0.001,
    )
    validation_logits = _logits(standardized_validation, weights, bias)
    temperatures = [0.5 + step * 0.05 for step in range(51)]
    temperature = min(
        temperatures,
        key=lambda candidate: _log_loss(validation_logits, validation_labels, candidate),
    )
    source_digest = hashlib.sha256(source.read_bytes()).hexdigest()
    artifact = {
        "artifactSchemaVersion": ARTIFACT_SCHEMA_VERSION,
        "contractVersion": CONTRACT_VERSION,
        "modelType": "softmax_regression",
        "modelVersion": model_version,
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "featureNames": FEATURE_NAMES,
        "classes": CLASS_NAMES,
        "standardization": {
            "means": [round(value, 10) for value in means],
            "scales": [round(value, 10) for value in scales],
        },
        "parameters": {
            "weights": [[round(value, 10) for value in row] for row in weights],
            "bias": [round(value, 10) for value in bias],
        },
        "calibration": {
            "temperature": round(temperature, 6),
            "confidenceThreshold": 0.62,
        },
        "training": {
            "sourceSha256": source_digest,
            "examples": len(vectors),
            "groups": len(set(groups)),
            "trainingExamples": len(train_vectors),
            "validationExamples": len(validation_vectors),
            "epochs": epochs,
            "split": "sha256(group_id) mod 5",
        },
        "validationMetrics": _metrics(
            validation_logits,
            validation_labels,
            temperature,
        ),
    }
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(artifact, indent=2) + "\n", encoding="utf-8")
    return artifact


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the Seedlings Vision softmax classifier.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--model-version", default="priority-softmax-v1")
    parser.add_argument("--epochs", type=int, default=500)
    args = parser.parse_args()
    artifact = train_model(
        args.input,
        args.output,
        model_version=args.model_version,
        epochs=args.epochs,
    )
    metrics = artifact["validationMetrics"]
    print(
        f"Wrote {artifact['modelVersion']} to {args.output} "
        f"(accuracy={metrics['accuracy']}, logLoss={metrics['logLoss']})"
    )


if __name__ == "__main__":
    main()
