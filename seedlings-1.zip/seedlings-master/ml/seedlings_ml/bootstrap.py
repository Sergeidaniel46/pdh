from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path

from .model import CLASS_NAMES

CSV_FIELDS = [
    "group_id",
    "scientific_name",
    "leaf_type",
    "occupancy",
    "height_mm",
    "height_ratio",
    "canopy_area_mm2",
    "green_fraction",
    "chlorotic_fraction",
    "necrotic_fraction",
    "coverage",
    "label",
]


def _bounded(random: random.Random, low: float, high: float) -> float:
    return round(random.uniform(low, high), 6)


def generate_rows(seed: int = 20260729, groups_per_class: int = 40) -> list[dict[str, str | float]]:
    generator = random.Random(seed)
    rows: list[dict[str, str | float]] = []
    for label in CLASS_NAMES:
        for group_index in range(groups_per_class):
            is_larch = group_index % 2 == 1
            scientific_name = "Larix kaempferi" if is_larch else "Idesia polycarpa"
            leaf_type = "needle" if is_larch else "broadleaf"
            reference_height = 190 if is_larch else 165
            for repeat in range(2):
                if label == "healthy":
                    occupancy = _bounded(generator, 0.055, 0.13)
                    ratio = _bounded(generator, 0.82, 1.18)
                    area = _bounded(generator, 1800, 6200)
                    green, chlorotic, necrotic = (
                        _bounded(generator, 0.8, 0.98),
                        _bounded(generator, 0, 0.08),
                        _bounded(generator, 0, 0.06),
                    )
                    coverage = _bounded(generator, 0.84, 1)
                elif label == "missing_or_dead":
                    occupancy = _bounded(generator, 0, 0.009)
                    ratio = _bounded(generator, 0, 0.12)
                    area = _bounded(generator, 0, 380)
                    green, chlorotic, necrotic = (
                        _bounded(generator, 0, 0.18),
                        _bounded(generator, 0, 0.08),
                        _bounded(generator, 0, 0.08),
                    )
                    coverage = _bounded(generator, 0.82, 1)
                elif label == "browning_necrosis":
                    occupancy = _bounded(generator, 0.045, 0.125)
                    ratio = _bounded(generator, 0.72, 1.15)
                    area = _bounded(generator, 1500, 5600)
                    green, chlorotic, necrotic = (
                        _bounded(generator, 0.25, 0.62),
                        _bounded(generator, 0, 0.13),
                        _bounded(generator, 0.22, 0.58),
                    )
                    coverage = _bounded(generator, 0.82, 1)
                elif label == "chlorosis":
                    occupancy = _bounded(generator, 0.045, 0.125)
                    ratio = _bounded(generator, 0.72, 1.15)
                    area = _bounded(generator, 1500, 5600)
                    green, chlorotic, necrotic = (
                        _bounded(generator, 0.22, 0.58),
                        _bounded(generator, 0.25, 0.62),
                        _bounded(generator, 0, 0.12),
                    )
                    coverage = _bounded(generator, 0.82, 1)
                elif label == "stunting":
                    occupancy = _bounded(generator, 0.025, 0.08)
                    ratio = _bounded(generator, 0.28, 0.58)
                    area = _bounded(generator, 650, 2200)
                    green, chlorotic, necrotic = (
                        _bounded(generator, 0.76, 0.97),
                        _bounded(generator, 0, 0.09),
                        _bounded(generator, 0, 0.07),
                    )
                    coverage = _bounded(generator, 0.82, 1)
                else:
                    occupancy = _bounded(generator, 0.045, 0.125)
                    ratio = _bounded(generator, 0.72, 1.15)
                    area = _bounded(generator, 1400, 5500)
                    green, chlorotic, necrotic = (
                        _bounded(generator, 0.7, 0.96),
                        _bounded(generator, 0, 0.1),
                        _bounded(generator, 0, 0.08),
                    )
                    coverage = _bounded(generator, 0.2, 0.58)
                height_mm = max(0, reference_height * ratio + generator.uniform(-4, 4))
                rows.append(
                    {
                        "group_id": f"{label}-{group_index:03d}",
                        "scientific_name": scientific_name,
                        "leaf_type": leaf_type,
                        "occupancy": occupancy,
                        "height_mm": round(height_mm, 6),
                        "height_ratio": ratio,
                        "canopy_area_mm2": area,
                        "green_fraction": green,
                        "chlorotic_fraction": chlorotic,
                        "necrotic_fraction": necrotic,
                        "coverage": coverage,
                        "label": label,
                        "_repeat": repeat,
                    }
                )
    return rows


def write_dataset(path: str | Path, seed: int = 20260729) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(generate_rows(seed=seed))


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a deterministic ML bootstrap dataset.")
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=20260729)
    args = parser.parse_args()
    write_dataset(args.output, seed=args.seed)
    print(f"Wrote bootstrap dataset to {args.output}")


if __name__ == "__main__":
    main()
