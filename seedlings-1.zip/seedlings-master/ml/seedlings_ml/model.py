from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

CONTRACT_VERSION = "1.0"
ARTIFACT_SCHEMA_VERSION = 1
FEATURE_NAMES = [
    "occupancy",
    "height_ratio",
    "green_fraction",
    "chlorotic_fraction",
    "necrotic_fraction",
    "coverage",
    "is_needle",
    "is_idesia",
    "is_larix",
]
CLASS_NAMES = [
    "healthy",
    "missing_or_dead",
    "browning_necrosis",
    "chlorosis",
    "stunting",
    "insufficient_view",
]


def _finite_number(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be numeric")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    return number


def feature_vector(
    features: dict[str, Any],
    scientific_name: str,
    leaf_type: str,
) -> list[float]:
    height_mm = _finite_number(features.get("heightMm"), "heightMm")
    canopy_area_mm2 = _finite_number(features.get("canopyAreaMm2"), "canopyAreaMm2")
    if height_mm < 0 or canopy_area_mm2 < 0:
        raise ValueError("height and canopy area cannot be negative")
    values = [
        _finite_number(features.get("occupancy"), "occupancy"),
        _finite_number(features.get("heightRatio"), "heightRatio"),
        _finite_number(features.get("greenFraction"), "greenFraction"),
        _finite_number(features.get("chloroticFraction"), "chloroticFraction"),
        _finite_number(features.get("necroticFraction"), "necroticFraction"),
        _finite_number(features.get("coverage"), "coverage"),
        1.0 if leaf_type == "needle" else 0.0,
        1.0 if scientific_name == "Idesia polycarpa" else 0.0,
        1.0 if scientific_name == "Larix kaempferi" else 0.0,
    ]
    for index in range(6):
        if values[index] < 0 or values[index] > 1.5:
            raise ValueError(f"{FEATURE_NAMES[index]} is outside the supported range")
    return values


@dataclass(frozen=True)
class Prediction:
    class_name: str
    confidence: float
    probabilities: dict[str, float]


class ModelArtifact:
    def __init__(self, payload: dict[str, Any]):
        self.payload = payload
        self._validate()
        self.model_version = payload["modelVersion"]
        self.classes = payload["classes"]
        self.means = [float(value) for value in payload["standardization"]["means"]]
        self.scales = [float(value) for value in payload["standardization"]["scales"]]
        self.weights = [
            [float(value) for value in row] for row in payload["parameters"]["weights"]
        ]
        self.bias = [float(value) for value in payload["parameters"]["bias"]]
        self.temperature = float(payload["calibration"]["temperature"])
        self.confidence_threshold = float(payload["calibration"]["confidenceThreshold"])

    @classmethod
    def load(cls, path: str | Path) -> "ModelArtifact":
        with Path(path).open("r", encoding="utf-8") as handle:
            return cls(json.load(handle))

    def _validate(self) -> None:
        if self.payload.get("artifactSchemaVersion") != ARTIFACT_SCHEMA_VERSION:
            raise ValueError("unsupported model artifact schema")
        if self.payload.get("contractVersion") != CONTRACT_VERSION:
            raise ValueError("model artifact contract version mismatch")
        if self.payload.get("modelType") != "softmax_regression":
            raise ValueError("unsupported model type")
        if self.payload.get("featureNames") != FEATURE_NAMES:
            raise ValueError("model feature schema mismatch")
        classes = self.payload.get("classes")
        if classes != CLASS_NAMES:
            raise ValueError("model class schema mismatch")
        feature_count = len(FEATURE_NAMES)
        class_count = len(CLASS_NAMES)
        standardization = self.payload.get("standardization", {})
        parameters = self.payload.get("parameters", {})
        if len(standardization.get("means", [])) != feature_count:
            raise ValueError("invalid standardization means")
        if len(standardization.get("scales", [])) != feature_count:
            raise ValueError("invalid standardization scales")
        weights = parameters.get("weights", [])
        if len(weights) != class_count or any(len(row) != feature_count for row in weights):
            raise ValueError("invalid model weights")
        if len(parameters.get("bias", [])) != class_count:
            raise ValueError("invalid model bias")
        calibration = self.payload.get("calibration", {})
        if float(calibration.get("temperature", 0)) <= 0:
            raise ValueError("invalid calibration temperature")
        threshold = float(calibration.get("confidenceThreshold", -1))
        if threshold < 0 or threshold > 1:
            raise ValueError("invalid confidence threshold")

    def predict(
        self,
        features: dict[str, Any],
        scientific_name: str,
        leaf_type: str,
    ) -> Prediction:
        raw = feature_vector(features, scientific_name, leaf_type)
        standardized = [
            (value - mean) / scale
            for value, mean, scale in zip(raw, self.means, self.scales, strict=True)
        ]
        logits = [
            (
                bias
                + sum(weight * value for weight, value in zip(row, standardized, strict=True))
            )
            / self.temperature
            for row, bias in zip(self.weights, self.bias, strict=True)
        ]
        maximum = max(logits)
        exponentials = [math.exp(value - maximum) for value in logits]
        total = sum(exponentials)
        probabilities = [value / total for value in exponentials]
        best_index = max(range(len(probabilities)), key=probabilities.__getitem__)
        return Prediction(
            class_name=self.classes[best_index],
            confidence=probabilities[best_index],
            probabilities=dict(zip(self.classes, probabilities, strict=True)),
        )


def finding_for_prediction(
    prediction: Prediction,
    features: dict[str, Any],
    confidence_threshold: float,
) -> dict[str, Any] | None:
    probabilities = {
        label: round(probability, 6)
        for label, probability in prediction.probabilities.items()
    }
    details = {
        "predictedClass": prediction.class_name,
        "classProbabilities": probabilities,
        "featureSnapshot": features,
    }
    if prediction.confidence < confidence_threshold:
        return {
            "category": "visible_abiotic_or_unknown_stress",
            "syndrome": "unknown_novel_pattern",
            "suspectedClass": None,
            "severity": 1,
            "confidence": round(prediction.confidence, 6),
            "evidenceLevel": "screening_only",
            "details": details,
        }
    if prediction.class_name == "healthy":
        return None

    category = {
        "missing_or_dead": "growth",
        "browning_necrosis": "visible_abiotic_or_unknown_stress",
        "chlorosis": "visible_abiotic_or_unknown_stress",
        "stunting": "growth",
        "insufficient_view": "quality_control",
    }[prediction.class_name]
    if prediction.class_name == "missing_or_dead":
        severity = 4
    elif prediction.class_name == "browning_necrosis":
        severity = 3 if float(features["necroticFraction"]) >= 0.35 else 2
    elif prediction.class_name == "chlorosis":
        severity = 3 if float(features["chloroticFraction"]) >= 0.4 else 2
    elif prediction.class_name == "stunting":
        severity = 2
    else:
        severity = 1
    return {
        "category": category,
        "syndrome": prediction.class_name,
        "suspectedClass": prediction.class_name,
        "severity": severity,
        "confidence": round(prediction.confidence, 6),
        "evidenceLevel": "screening_only",
        "details": details,
    }
