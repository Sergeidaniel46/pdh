from __future__ import annotations

import argparse
import json
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .model import CONTRACT_VERSION, ModelArtifact, finding_for_prediction

MAX_REQUEST_BYTES = 2 * 1024 * 1024


class InferenceEngine:
    def __init__(self, model: ModelArtifact):
        self.model = model

    def predict(self, payload: dict[str, Any]) -> dict[str, Any]:
        if payload.get("contractVersion") != CONTRACT_VERSION:
            raise ValueError(f"contractVersion must be {CONTRACT_VERSION}")
        session = payload.get("session")
        cells = payload.get("cells")
        if not isinstance(session, dict) or not isinstance(cells, list):
            raise ValueError("session must be an object and cells must be an array")
        scientific_name = session.get("scientificName")
        leaf_type = session.get("leafType")
        if not isinstance(scientific_name, str) or leaf_type not in {"needle", "broadleaf"}:
            raise ValueError("session taxonomy is invalid")
        predictions = []
        seen = set()
        for cell in cells:
            if not isinstance(cell, dict) or not isinstance(cell.get("features"), dict):
                raise ValueError("each cell must contain a features object")
            row_index = cell.get("rowIndex")
            column_index = cell.get("columnIndex")
            if not isinstance(row_index, int) or not isinstance(column_index, int):
                raise ValueError("cell coordinates must be integers")
            key = (row_index, column_index)
            if key in seen:
                raise ValueError(f"duplicate cell coordinates: {row_index}:{column_index}")
            seen.add(key)
            model_prediction = self.model.predict(
                cell["features"],
                scientific_name=scientific_name,
                leaf_type=leaf_type,
            )
            predictions.append(
                {
                    "rowIndex": row_index,
                    "columnIndex": column_index,
                    "className": model_prediction.class_name,
                    "confidence": round(model_prediction.confidence, 6),
                    "finding": finding_for_prediction(
                        model_prediction,
                        cell["features"],
                        self.model.confidence_threshold,
                    ),
                }
            )
        return {
            "contractVersion": CONTRACT_VERSION,
            "modelVersion": self.model.model_version,
            "predictions": predictions,
        }


def handler_for(engine: InferenceEngine) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        def _json(self, status: HTTPStatus, payload: dict[str, Any]) -> None:
            body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
            self.send_response(status.value)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if self.path != "/health":
                self._json(HTTPStatus.NOT_FOUND, {"error": "route not found"})
                return
            self._json(
                HTTPStatus.OK,
                {
                    "status": "ready",
                    "contractVersion": CONTRACT_VERSION,
                    "modelVersion": engine.model.model_version,
                },
            )

        def do_POST(self) -> None:
            if self.path != "/v1/predict":
                self._json(HTTPStatus.NOT_FOUND, {"error": "route not found"})
                return
            try:
                content_length = int(self.headers.get("content-length", "0"))
                if content_length <= 0 or content_length > MAX_REQUEST_BYTES:
                    raise ValueError("request body size is invalid")
                payload = json.loads(self.rfile.read(content_length))
                if not isinstance(payload, dict):
                    raise ValueError("request body must be an object")
                self._json(HTTPStatus.OK, engine.predict(payload))
            except (ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
                self._json(HTTPStatus.BAD_REQUEST, {"error": str(error)})
            except Exception:
                self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "inference failed"})

        def log_message(self, format: str, *args: Any) -> None:
            print(f"[ml-service] {self.address_string()} {format % args}")

    return Handler


def main() -> None:
    default_model = Path(__file__).resolve().parents[1] / "artifacts" / "priority-softmax-v1.json"
    parser = argparse.ArgumentParser(description="Serve Seedlings Vision ML inference.")
    parser.add_argument("--model", default=str(default_model))
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8100)
    args = parser.parse_args()
    engine = InferenceEngine(ModelArtifact.load(args.model))
    server = ThreadingHTTPServer((args.host, args.port), handler_for(engine))
    print(
        f"Seedlings ML {engine.model.model_version} listening on "
        f"http://{args.host}:{args.port}"
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
