"""Training and inference package for Seedlings Vision."""

from .model import CONTRACT_VERSION, ModelArtifact

__all__ = ["CONTRACT_VERSION", "ModelArtifact"]
