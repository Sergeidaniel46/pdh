from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from seedlings_ml.bootstrap import write_dataset
from seedlings_ml.model import CLASS_NAMES, ModelArtifact
from seedlings_ml.service import InferenceEngine
from seedlings_ml.train import train_model


ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = ROOT / "ml" / "artifacts" / "priority-softmax-v1.json"


def features(**overrides: float) -> dict[str, float]:
    values = {
        "occupancy": 0.09,
        "heightMm": 170,
        "heightRatio": 1,
        "canopyAreaMm2": 3500,
        "greenFraction": 0.9,
        "chloroticFraction": 0.03,
        "necroticFraction": 0.02,
        "coverage": 1,
    }
    values.update(overrides)
    return values


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.model = ModelArtifact.load(MODEL_PATH)

    def test_committed_artifact_recognizes_each_supported_class(self) -> None:
        cases = {
            "healthy": features(),
            "missing_or_dead": features(
                occupancy=0.002,
                heightMm=2,
                heightRatio=0.01,
                canopyAreaMm2=50,
                greenFraction=0.05,
            ),
            "browning_necrosis": features(
                greenFraction=0.4,
                necroticFraction=0.4,
            ),
            "chlorosis": features(
                greenFraction=0.4,
                chloroticFraction=0.45,
            ),
            "stunting": features(
                occupancy=0.05,
                heightMm=70,
                heightRatio=0.42,
                canopyAreaMm2=1200,
            ),
            "insufficient_view": features(coverage=0.35),
        }
        self.assertEqual(set(cases), set(CLASS_NAMES))
        for expected, inputs in cases.items():
            with self.subTest(expected=expected):
                prediction = self.model.predict(
                    inputs,
                    scientific_name="Idesia polycarpa",
                    leaf_type="broadleaf",
                )
                self.assertEqual(prediction.class_name, expected)
                self.assertGreater(prediction.confidence, 0.9)

    def test_inference_contract_returns_model_findings(self) -> None:
        result = InferenceEngine(self.model).predict(
            {
                "contractVersion": "1.0",
                "session": {
                    "scientificName": "Larix kaempferi",
                    "leafType": "needle",
                },
                "cells": [
                    {"rowIndex": 0, "columnIndex": 0, "features": features()},
                    {
                        "rowIndex": 0,
                        "columnIndex": 1,
                        "features": features(
                            greenFraction=0.35,
                            chloroticFraction=0.5,
                        ),
                    },
                ],
            }
        )
        self.assertEqual(result["contractVersion"], "1.0")
        self.assertEqual(result["modelVersion"], "priority-softmax-v1")
        self.assertIsNone(result["predictions"][0]["finding"])
        self.assertEqual(
            result["predictions"][1]["finding"]["syndrome"],
            "chlorosis",
        )

    def test_bootstrap_training_pipeline_writes_a_valid_artifact(self) -> None:
        with tempfile.TemporaryDirectory(prefix="seedlings-ml-test-") as directory:
            dataset = Path(directory) / "training.csv"
            artifact_path = Path(directory) / "model.json"
            write_dataset(dataset)
            artifact = train_model(
                dataset,
                artifact_path,
                model_version="test-softmax",
                epochs=120,
            )
            loaded = ModelArtifact.load(artifact_path)
            self.assertEqual(loaded.model_version, "test-softmax")
            self.assertEqual(artifact["training"]["groups"], 240)
            self.assertGreaterEqual(artifact["validationMetrics"]["accuracy"], 0.9)


if __name__ == "__main__":
    unittest.main()
