import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import http from "node:http";
import { DatabaseSync } from "node:sqlite";
import sharp from "sharp";
import { buildApp } from "../src/app.js";
import { createDatabase, seedDemoData } from "../src/db.js";

async function testApp(t, overrides = {}) {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "seedlings-test-"));
  const app = await buildApp({
    logger: false,
    databasePath: ":memory:",
    imageDir: path.join(directory, "images"),
    ...overrides
  });
  t.after(async () => {
    await app.close();
    await fs.rm(directory, { recursive: true, force: true });
  });
  return app;
}

async function inferenceServer(t, responder) {
  const requests = [];
  const server = http.createServer(async (request, response) => {
    const chunks = [];
    for await (const chunk of request) chunks.push(chunk);
    const payload = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    requests.push(payload);
    const result = responder(payload);
    response.writeHead(result.statusCode ?? 200, { "content-type": "application/json" });
    response.end(JSON.stringify(result.body));
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise((resolve) => server.close(resolve)));
  return {
    requests,
    url: `http://127.0.0.1:${server.address().port}`
  };
}

test("health and seeded trays are available", async (t) => {
  const app = await testApp(t);
  const health = await app.inject({ method: "GET", url: "/api/health" });
  assert.equal(health.statusCode, 200);
  assert.equal(health.json().status, "ok");

  const trays = await app.inject({ method: "GET", url: "/api/trays" });
  assert.equal(trays.statusCode, 200);
  assert.equal(trays.json().length, 2);
  assert.deepEqual(
    trays.json().map((tray) => tray.scientific_name),
    ["Idesia polycarpa", "Larix kaempferi"]
  );
  assert.deepEqual(new Set(trays.json().map((tray) => tray.leaf_type)), new Set(["needle", "broadleaf"]));
  assert.deepEqual(trays.json().map((tray) => tray.priority_rank), [1, 2]);
  assert.equal(trays.json()[1].scientific_name_alias, "Larix leptolepis");

  const species = await app.inject({ method: "GET", url: "/api/species" });
  assert.deepEqual(
    species.json().map(({ scientific_name, scientific_name_alias }) => ({
      scientific_name,
      scientific_name_alias
    })),
    [
      { scientific_name: "Idesia polycarpa", scientific_name_alias: null },
      { scientific_name: "Larix kaempferi", scientific_name_alias: "Larix leptolepis" }
    ]
  );

  const dashboard = await app.inject({ method: "GET", url: "/api/dashboard" });
  assert.equal(dashboard.json().prioritySpecies, 2);
  assert.equal(dashboard.json().priorityTrays, 2);
  assert.equal(dashboard.json().prioritySeedlings, 24);
});

test("simulated 25-view scan produces cell observations and reviewable alerts", async (t) => {
  const app = await testApp(t);
  for (const tray of app.system.repository.listTrays()) {
    const scan = await app.inject({
      method: "POST",
      url: "/api/simulate",
      payload: { trayId: tray.id, seed: 7 }
    });
    assert.equal(scan.statusCode, 200, scan.body);
    const result = scan.json();
    assert.equal(result.views, 25);
    assert.equal(result.analysis.status, "processed");
    assert.equal(result.analysis.passRate, 1);
    assert.ok(result.analysis.observations >= tray.rows * tray.columns * 7);
    assert.ok(result.analysis.findings >= 3);
    assert.ok(result.analysis.alerts >= 3);

    const detail = await app.inject({ method: "GET", url: `/api/sessions/${result.sessionId}` });
    assert.equal(detail.statusCode, 200);
    assert.equal(detail.json().views.length, 25);
    assert.equal(detail.json().status, "processed");
    assert.equal(detail.json().scientific_name, tray.scientific_name);
    assert.ok(detail.json().observations.some((item) => item.metric === "height"));
    assert.ok(detail.json().findings.some((item) => item.syndrome === "missing_or_dead"));
  }
});

test("configured Python inference drives findings through the versioned contract", async (t) => {
  const inference = await inferenceServer(t, (payload) => ({
    body: {
      contractVersion: "1.0",
      modelVersion: "test-python-ml-v1",
      predictions: payload.cells.map((cell) => {
        let finding = null;
        if (cell.features.occupancy < 0.012) {
          finding = {
            category: "growth",
            syndrome: "missing_or_dead",
            severity: 4,
            confidence: 0.97,
            evidenceLevel: "screening_only",
            details: { source: "test-model" }
          };
        } else if (cell.features.chloroticFraction >= 0.22) {
          finding = {
            category: "visible_abiotic_or_unknown_stress",
            syndrome: "chlorosis",
            severity: 2,
            confidence: 0.91,
            evidenceLevel: "screening_only",
            details: { source: "test-model" }
          };
        }
        return {
          rowIndex: cell.rowIndex,
          columnIndex: cell.columnIndex,
          finding
        };
      })
    }
  }));
  const app = await testApp(t, {
    ml: { url: inference.url, mode: "required", timeoutMs: 2_000 }
  });
  const tray = app.system.repository.listTrays()[0];
  const scan = await app.inject({
    method: "POST",
    url: "/api/simulate",
    payload: { trayId: tray.id, seed: 7 }
  });
  assert.equal(scan.statusCode, 200, scan.body);
  assert.equal(scan.json().analysis.analysisEngine, "python_ml");
  assert.equal(scan.json().analysis.modelVersion, "test-python-ml-v1");
  assert.equal(inference.requests.length, 1);
  assert.equal(inference.requests[0].contractVersion, "1.0");
  assert.equal(inference.requests[0].session.scientificName, "Idesia polycarpa");
  assert.equal(inference.requests[0].cells.length, tray.rows * tray.columns);
  const detail = app.system.repository.getSessionDetail(scan.json().sessionId);
  assert.equal(detail.model_version, "test-python-ml-v1");
  assert.ok(detail.findings.every((finding) => finding.details.source === "test-model"));
});

test("ML service errors honor fallback and required processing policies", async (t) => {
  const inference = await inferenceServer(t, () => ({
    statusCode: 503,
    body: { error: "model warming up" }
  }));
  const app = await testApp(t, {
    ml: { url: inference.url, mode: "fallback", timeoutMs: 2_000 }
  });
  const tray = app.system.repository.listTrays()[0];
  const scan = await app.inject({
    method: "POST",
    url: "/api/simulate",
    payload: { trayId: tray.id, seed: 7 }
  });
  assert.equal(scan.statusCode, 200, scan.body);
  assert.equal(scan.json().analysis.analysisEngine, "baseline_fallback");
  assert.equal(scan.json().analysis.modelVersion, "baseline-rgb-v1");
  assert.match(scan.json().analysis.fallbackReason, /HTTP 503/);

  const requiredApp = await testApp(t, {
    ml: { url: inference.url, mode: "required", timeoutMs: 2_000 }
  });
  const requiredTray = requiredApp.system.repository.listTrays()[0];
  const failedScan = await requiredApp.inject({
    method: "POST",
    url: "/api/simulate",
    payload: { trayId: requiredTray.id, seed: 7 }
  });
  assert.equal(failedScan.statusCode, 400);
  assert.match(failedScan.json().error, /HTTP 503/);
  assert.equal(requiredApp.system.repository.listSessions()[0].status, "analysis_failed");
});

test("legacy species migrate without losing history or duplicating targets", async (t) => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), "seedlings-legacy-"));
  const databasePath = path.join(directory, "legacy.sqlite");
  const legacy = new DatabaseSync(databasePath);
  legacy.exec(`
    CREATE TABLE species (
      id INTEGER PRIMARY KEY,
      scientific_name TEXT NOT NULL UNIQUE,
      common_name TEXT NOT NULL,
      leaf_type TEXT NOT NULL CHECK (leaf_type IN ('needle', 'broadleaf'))
    );
    INSERT INTO species (scientific_name, common_name, leaf_type)
    VALUES ('Pinus thunbergii', 'Japanese black pine', 'needle');
  `);
  legacy.close();

  const db = createDatabase(databasePath);
  t.after(async () => {
    db.close();
    await fs.rm(directory, { recursive: true, force: true });
  });
  const pineId = db.prepare(
    "SELECT id FROM species WHERE scientific_name = 'Pinus thunbergii'"
  ).get().id;
  const cohortId = Number(db.prepare(`
    INSERT INTO cohorts (name, species_id, seed_lot)
    VALUES ('Historical pine', ?, 'PINE-HISTORY')
  `).run(pineId).lastInsertRowid);
  const trayId = Number(db.prepare(`
    INSERT INTO trays (tray_code, cohort_id, rows, columns)
    VALUES ('PINE-HIST-001', ?, 1, 1)
  `).run(cohortId).lastInsertRowid);
  db.prepare(`
    INSERT INTO capture_sessions (tray_id, captured_at, status)
    VALUES (?, '2025-01-01T00:00:00.000Z', 'processed')
  `).run(trayId);

  seedDemoData(db);
  seedDemoData(db);

  const columns = db.prepare("PRAGMA table_info(species)").all().map((column) => column.name);
  assert.ok(columns.includes("scientific_name_alias"));
  assert.ok(columns.includes("priority_rank"));
  assert.ok(db.prepare(
    "SELECT id FROM species WHERE scientific_name = 'Pinus thunbergii'"
  ).get());
  assert.equal(db.prepare(
    "SELECT COUNT(*) AS count FROM species WHERE priority_rank IS NOT NULL"
  ).get().count, 2);
  assert.equal(db.prepare(
    "SELECT COUNT(*) AS count FROM trays WHERE tray_code IN ('IDESIA-A-001', 'LARCH-A-001')"
  ).get().count, 2);
  assert.equal(db.prepare(
    "SELECT COUNT(*) AS count FROM capture_sessions WHERE tray_id = ?"
  ).get(trayId).count, 1);
});

test("a dark uploaded image fails capture quality control", async (t) => {
  const app = await testApp(t);
  const tray = app.system.repository.listTrays()[0];
  const sessionId = await app.system.captureService.createSession({ trayId: tray.id });
  const dark = await sharp({
    create: { width: 800, height: 600, channels: 3, background: "#030303" }
  }).png().toBuffer();
  const result = await app.system.captureService.addView({
    sessionId,
    sequenceIndex: 0,
    angleDeg: 0,
    elevation: "low",
    mmPerPixel: 0.5,
    buffer: dark,
    filename: "dark.png"
  });
  assert.equal(result.qc.pass, false);
  assert.ok(result.qc.reasons.includes("underexposed"));
});

test("alert acknowledgement and expert review are audited", async (t) => {
  const app = await testApp(t);
  const tray = app.system.repository.listTrays()[0];
  const scan = await app.inject({
    method: "POST",
    url: "/api/simulate",
    payload: { trayId: tray.id }
  });
  const detail = app.system.repository.getSessionDetail(scan.json().sessionId);
  const finding = detail.findings.find((item) => item.severity >= 2);
  const alert = app.system.repository.listAlerts("open")[0];
  assert.ok(["Idesia polycarpa", "Larix kaempferi"].includes(alert.scientific_name));

  const acknowledge = await app.inject({
    method: "POST",
    url: `/api/alerts/${alert.id}/acknowledge`
  });
  assert.equal(acknowledge.statusCode, 200);
  assert.equal(acknowledge.json().status, "acknowledged");

  const review = await app.inject({
    method: "POST",
    url: `/api/findings/${finding.id}/reviews`,
    payload: {
      reviewer: "Dr. Nursery",
      decision: "confirmed",
      diagnosis: "drought stress",
      evidenceLevel: "expert_confirmed",
      notes: "Confirmed during tray inspection."
    }
  });
  assert.equal(review.statusCode, 201);
  const updated = app.system.repository.getSessionDetail(scan.json().sessionId)
    .findings.find((item) => item.id === finding.id);
  assert.equal(updated.review_status, "confirmed");
  assert.equal(updated.evidence_level, "expert_confirmed");
});
