import { buildApp } from "../src/app.js";
import { simulateCapture } from "../src/services/simulator.js";

const app = await buildApp({ logger: false });
try {
  const trayId = Number(process.argv[2] ?? app.system.repository.listTrays()[0]?.id);
  if (!trayId) throw new Error("No tray is configured");
  const result = await simulateCapture({
    captureService: app.system.captureService,
    repository: app.system.repository,
    trayId
  });
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
} finally {
  await app.close();
}

