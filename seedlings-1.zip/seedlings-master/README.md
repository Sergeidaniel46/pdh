# Seedlings Vision MVP

A runnable vertical slice of the multi-view tree-nursery inspection plan in
[RESEARCH_AND_SYSTEM_PLAN.md](./RESEARCH_AND_SYSTEM_PLAN.md).

The MVP provides:

- priority cohorts for *Idesia polycarpa* (Igiri tree) and Japanese larch
  (*Larix kaempferi*, synonym *Larix leptolepis*);
- a 25-view rotating-camera capture contract;
- image-quality checks for resolution, exposure, clipping, and sharpness;
- stable tray/cell identities for conifer and broadleaf batches;
- explainable RGB growth traits and multi-view aggregation;
- a versioned Node-to-Python inference contract;
- dependency-free Python training, calibration, artifact validation, and serving;
- visible chlorosis, necrosis, missing/dead, stunting, and insufficient-view screening;
- alert acknowledgement and expert/laboratory review records;
- immutable local image storage and a SQLite operational database;
- a simulator that uses the same ingest and processing path as camera uploads;
- an operator dashboard and JSON API.

The repository includes both a transparent RGB fallback and a trained softmax
screening model. The committed model is trained on deterministic synthetic
bootstrap features so the architecture is runnable and testable; its metrics
are not evidence of biological validity. Replace it with local,
expert/lab-confirmed training data before operational use or named-disease work.

## Run

Requirements: Node.js 22 or later.

```bash
npm install
npm start
```

Open <http://127.0.0.1:3100>. Click **Run simulated 25-view scan** to exercise
capture, QC, analysis, alerts, and the per-cell dashboard.

Fresh databases contain one priority tray for each target species. Existing
databases are migrated without deleting historical species or scans; target
trays appear first and older trays remain available under the historical group.

Run the simulator without the browser:

```bash
npm run simulate
```

Run verification:

```bash
npm test
npm run check
```

Runtime data is written under `data/` and is intentionally ignored by Git.

## Run the hybrid ML path

The Python package uses only the standard library and requires Python 3.11 or
later. Start the inference service:

```bash
npm run ml:serve
```

In another terminal, require Python inference and start the Node control plane:

```bash
ML_INFERENCE_URL=http://127.0.0.1:8100 \
ML_INFERENCE_MODE=required \
npm start
```

`ML_INFERENCE_MODE=fallback` keeps capture operational and records
`baseline-rgb-v1` when the ML service is unavailable. `required` instead marks
the session `analysis_failed` and returns an error. The default timeout is
10 seconds and can be changed with `ML_INFERENCE_TIMEOUT_MS`.

Node performs image QC, cell registration, and explainable feature extraction.
It sends one JSON request per session to `POST /v1/predict`; Python validates the
contract and artifact, standardizes features, applies calibrated inference, and
returns per-cell findings. Node remains the only writer to the operational
database and records the exact returned model version.

### Train a model

Training CSV files require `group_id`, taxonomy, the eight measured feature
columns, and `label`. Group IDs keep repeat observations of one biological
sample on the same side of the deterministic train/validation split.

```bash
PYTHONPATH=ml python3 -m seedlings_ml.train \
  --input /path/to/expert-confirmed-features.csv \
  --output ml/artifacts/priority-softmax-v2.json \
  --model-version priority-softmax-v2
```

For architecture testing only, reproduce the bundled synthetic bootstrap model:

```bash
npm run ml:train
```

The JSON artifact contains the feature/class schemas, normalization parameters,
weights, calibration temperature, confidence threshold, dataset digest, split
metadata, and validation metrics. Low-confidence predictions abstain as
`unknown_novel_pattern`.

## Real rotating-camera integration

The hardware controller uses three API operations:

1. Create a session:

```http
POST /api/capture-sessions
Content-Type: application/json

{"trayId": 1, "captureProgram": "orbit-25-v1"}
```

2. Upload each stopped, settled camera view:

```http
POST /api/capture-sessions/{sessionId}/views
Content-Type: multipart/form-data

file=<image>
sequenceIndex=0
angleDeg=0
elevation=low
mmPerPixel=0.5
```

Valid elevations are `low`, `high`, `zenith`, and `macro`. The production
sequence is 12 low views, 12 high views, and one zenith view.

3. Process the complete session:

```http
POST /api/capture-sessions/{sessionId}/process
```

The controller should stop motion before each exposure, wait for vibration to
settle, lock exposure/white balance/focus, and submit the physical pose and
calibration scale with the image.

An abbreviated OpenAPI description is served at `/api/openapi.json`.

## Project layout

```text
src/
  app.js                         API and application composition
  db.js                          SQLite schema and demo cohorts
  repository.js                  versioned operational records
  services/
    capture-service.js           hardware-neutral ingest contract
    image-qc.js                  automatic image acceptance
    baseline-analysis.js         explainable per-cell RGB measurements
    hybrid-analysis.js           ML routing and fallback policy
    ml-inference-client.js       versioned Python service client
    simulator.js                 25-view synthetic camera adapter
ml/
  seedlings_ml/                  training, model, and HTTP inference code
  artifacts/                     validated versioned model artifacts
  tests/                         Python model and training tests
public/                          operator dashboard
scripts/simulate.js              command-line simulation
test/system.test.js              end-to-end and QC tests
```

## Current boundary

The baseline expects a calibrated view in which the tray cell grid can be
projected into the image. The simulator already produces that geometry. Real
hardware must add fiducial-based pose recovery and perspective rectification
before replacing the grid projection. The data/API boundary is stable for that
upgrade.

The simulator renders target-specific Idesia and larch forms. The Python
bootstrap model is species-conditioned and genuinely trained, but its synthetic
dataset is useful only for software verification. `baseline-rgb-v1` remains the
explainable offline fallback and regression oracle.

Do not use v1 output to trigger automatic pesticide, disposal, or treatment
actions. All actionable findings remain human-authorized.
