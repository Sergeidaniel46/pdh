# Multi-View Tree-Nursery Seedling Growth, Pest, and Disease Recognition System

## 1. Executive decision

Build an operational, human-in-the-loop pilot for a container nursery using one calibrated RGB camera on a motorized arm. The camera moves around one standardized batch, captures two oblique 360-degree rings plus one overhead view, and produces:

1. Per-cell occupancy, survival, height, canopy area/volume proxy, color, growth rate, and cohort-relative vigor.
2. Visible symptom location and severity, followed by a cautious named diagnosis only for a small, locally verified target list.
3. Counts and classification of small flying pests from sticky cards photographed at a separate macro waypoint by the same camera.
4. An anomaly/inspection queue for unfamiliar symptoms, weak evidence, or unhealthy growth patterns.

This is not a universal camera-only pathology system. RGB imagery cannot reliably distinguish every disease from nutrient, water, heat, or chemical stress, and it cannot see roots or consistently identify presymptomatic infection. The pilot must therefore preserve an `unknown/other` result, quantify uncertainty, and route actionable detections to nursery experts. Named disease labels require expert review and occasional laboratory confirmation.

The initial priority species are broadleaf *Idesia polycarpa* (Igiri tree) and needle-leaved Japanese larch (*Larix kaempferi*, with *Larix leptolepis* retained as a taxonomic synonym). The design uses species-conditioned models and baselines rather than forcing them into one universal definition of healthy growth. Other species are added only after passing the same validation gates.

## 2. Evidence from related work

| Evidence | Relevance to this system |
|---|---|
| [Tree-seedling stereovision across spruce, pine, beech, and oak](https://doi.org/10.3389/fpls.2016.01644) found that image-derived height was a useful growth proxy for needle-leaved seedlings, while greenness was more useful for broadleaf seedlings. | Use separate species/leaf-type growth baselines and retain both structure and color features. |
| [Multi-view contour-constrained seedling reconstruction](https://doi.org/10.1016/j.biosystemseng.2024.05.011) reported strong agreement for height, stem diameter, and several leaf traits. | Calibrated multi-view geometry can provide useful morphology, but validation must be repeated on the actual species and tray geometry. |
| [Fast viewpoint-planned seedling reconstruction](https://doi.org/10.1016/j.compag.2024.108708) showed that informative viewpoints can reduce redundant capture. | Start with a conservative fixed view set, then reduce views only through an ablation study against accuracy and coverage. |
| [Densely planted seedling reconstruction](https://doi.org/10.1016/j.plaphe.2025.100122) reported strong height agreement from multi-view imagery. | Multi-view reconstruction is feasible for dense seedlings, but occlusion and per-plant ownership remain explicit test cases. |
| [RGB-D nursery-seedling monitoring](https://doi.org/10.1016/j.aiia.2019.09.001) reported very strong height agreement but much weaker stem-diameter agreement. | Treat height as a primary output; do not promise reliable root-collar diameter until locally validated. |
| [Forest-container nursery sensing mounted on an irrigation boom](https://doi.org/10.1007/s11056-024-10083-5) used repeated active spectral and laser measurements to monitor oak seedlings. | Repeated, geometrically consistent scans and environmental metadata matter as much as model choice. |
| [Forest seedling quality reviews](https://research.fs.usda.gov/treesearch/40175) emphasize height and root-collar diameter but also warn that quality is species- and use-specific. | The system reports measurable traits and deviations from agreed targets; nursery managers define readiness thresholds by species and stock type. |
| [Scots pine RGB phenotyping](https://doi.org/10.1186/s13595-025-01308-4) standardized color with a white reference and quantified seasonal needle-color shifts. | Color calibration and season/phenology-aware baselines are mandatory for conifers. |
| [PlantDoc](https://arxiv.org/abs/1911.10317) was created because controlled leaf datasets do not represent real scenes well. [A cross-dataset study](https://doi.org/10.1109/ACCESS.2023.3240100) likewise found a substantial lab-to-field generalization gap. | Public datasets may initialize models, but final training, thresholds, and testing must use local images from the actual rig. |
| Hyperspectral studies detected [white pine blister rust](https://doi.org/10.3390/rs12244041) and investigated [fusiform rust in loblolly pine seedlings](https://doi.org/10.3390/rs13183595). Another study found limited reliable presymptomatic indicators for rapid ʻōhiʻa death ([Perroy et al.](https://doi.org/10.3390/rs12111846)). | Spectral sensing can help for a validated pathogen–host pair, but it is not a general early-disease guarantee. RGB remains the v1 sensor; add spectral hardware only after a paired trial proves operational value. |
| [IP102](https://openaccess.thecvf.com/content_CVPR_2019/html/Wu_IP102_A_Large-Scale_Benchmark_Dataset_for_Insect_Pest_Recognition_CVPR_2019_paper.html) contains more than 75,000 pest images but has long-tailed classes. [Tiny-pest sticky-trap detection](https://doi.org/10.1016/j.compag.2021.106048) demonstrates the more operational acquisition pattern. | Use public pest data only for pretraining. Collect local sticky-card images at known scale for target species, counting, and alert thresholds. |

## 3. What the pilot will and will not recognize

### 3.1 Supported growth outputs

Each seedling cell receives:

- emergence/occupancy and mortality status;
- plant height and height increment;
- top-view projected canopy area;
- multi-view silhouette area and coarse canopy-volume proxy;
- broadleaf leaf-area proxy and visible leaf count where separable;
- needle-canopy density/greenness proxy for conifers, not individual needle count;
- calibrated color features, chlorosis/browning fraction, and visible necrotic area;
- lean/uprightness, gross deformation, breakage, and spatial competition;
- growth percentile and deviation from the same species, seed lot, sowing date, treatment, and production block;
- measurement uncertainty and view-coverage score.

Root health, root biomass, shoot-to-root ratio, water potential, nutrient concentration, pathogen identity, and outplanting survival are not directly observable. They require destructive sampling, laboratory tests, other sensors, or outcome-linked calibration. Root-collar diameter is experimental until the collar is visible and local error targets are met.

### 3.2 Health label hierarchy

Use a hierarchy rather than a flat disease classifier:

1. `apparently_healthy`
2. `visible_abiotic_or_unknown_stress`
   - chlorosis
   - browning/necrosis
   - wilting
   - stunting
   - scorch
   - mechanical damage
3. `suspected_named_disease`
   - limited to the locally approved priority list
4. `visible_pest_or_pest_damage`
5. `unknown_novel_pattern`
6. `insufficient_view`

Every named diagnosis stores its evidence level:

- `screening_only`
- `expert_confirmed`
- `laboratory_confirmed`

The interface must say “suspected” unless the current observation has the appropriate confirmation.

### 3.3 Pest scope

- Large, visible pests or egg masses on foliage may be detected opportunistically.
- Small flying insects are counted and classified on yellow/blue sticky cards using the same camera at a close-range, uniformly lit waypoint.
- Mites, cryptic larvae, insects under leaves, and early root pests are out of scope for reliable canopy scanning.
- Pest alerts are based on count trends and locally defined integrated-pest-management thresholds, not model confidence alone.

## 4. Single-camera acquisition cell

### 4.1 Mechanical layout

Use one industrial RGB area-scan camera on a rigid U-shaped or circular arm with:

- 360-degree azimuth motion around the batch;
- a vertical linear stage and motorized tilt;
- absolute or homed position sensing;
- an emergency stop, motion interlock, hard travel limits, and collision envelope;
- a fixed tray nest so the batch returns to the same coordinate system;
- a macro docking position for sticky cards and expert-selected close-ups.

The standard routine capture is:

1. 12 views at 30-degree intervals from a low-oblique elevation.
2. 12 views at 30-degree intervals from a high-oblique elevation.
3. One zenith/top view.
4. A color/scale reference frame at the start of each session.

This gives 25 images per batch. During dataset development, capture an extended 49-view sequence (24 views per ring plus zenith) on a representative subset. An ablation study may replace the 25-view routine with fewer views only if all key metrics change by less than 2% and no target class loses more than 3 percentage points of recall.

Use step-and-shoot motion. Stop the arm, wait for vibration to settle, trigger the camera and lights, and then move. Pause fans and irrigation during the approximately 30–90 second capture to avoid plant motion and water artifacts.

### 4.2 Camera and optics acceptance specification

Select the camera and lens by measurable image quality, not brand:

- native horizontal resolution sufficient for at most 0.25 mm/pixel at the plant plane;
- at least 12-bit RAW capture plus a high-quality derived image;
- global shutter preferred; a mechanical shutter is acceptable for stationary step-and-shoot capture;
- manual, lockable exposure, white balance, focus, aperture, and gain;
- low-distortion fixed focal-length lens with enough depth of field for the full canopy;
- focus and modulation-transfer performance verified across the complete batch volume;
- weather/dust protection appropriate to the nursery;
- cross-polarized, high-color-rendering, diffuse LED illumination;
- no mixed sunlight during calibrated inspection, using an enclosure or opaque curtains where needed.

For a 1,000 mm-wide field, 0.25 mm/pixel requires at least 4,000 horizontal pixels. Tiny pests need a separate close-up geometry; simply increasing the wide scene resolution is not sufficient.

### 4.3 Calibration and identity

- Permanently mount fiducial markers around the tray nest to recover camera pose and catch mechanical drift.
- Calibrate lens intrinsics initially, after maintenance, and whenever reprojection error exceeds the limit.
- Include a metric scale and neutral/color reference in a fixed location.
- Identify trays with a machine-readable tray ID; derive seedling identity from `tray_id + cell_row + cell_column`.
- Log camera settings, arm pose, light state, temperature, relative humidity, irrigation event, batch ID, species, seed lot, sowing date, and treatment.
- Reject or rescan blurred, saturated, underexposed, marker-missing, water-obscured, or motion-corrupted sessions before inference.

### 4.4 Occlusion rule

A camera orbit gives 360-degree coverage of the batch, not necessarily of every plant. Interior plants in dense trays can remain hidden behind neighbors.

For every seedling, calculate:

- number of usable views;
- angular coverage;
- visible silhouette fraction;
- top-view cell separation;
- symptom-pixel resolution.

If coverage is below the locally validated threshold, return `insufficient_view`; do not silently infer health. If full individual inspection is required, scan smaller sub-batches or create spacing between containers. The pilot must compare full-tray and spaced-batch modes before selecting an operating mode.

## 5. Software and data architecture

```text
Arm/camera controller
        |
        v
Capture validation --> immutable image/object storage
        |                        |
        v                        v
Session metadata ----------> processing queue
                                 |
                +----------------+----------------+
                |                |                |
           tray/cell map    growth pipeline   health/pest pipeline
                +----------------+----------------+
                                 |
                         observation database
                                 |
                     alerts + review dashboard
                                 |
                  expert corrections / lab results
                                 |
                      versioned training dataset
```

Recommended implementation stack:

- Python, OpenCV, and a PyTorch-based training/inference service;
- calibrated multi-view geometry with COLMAP used as a research/validation tool, not a mandatory dependency for every routine scan;
- PostgreSQL for operational metadata and observations;
- S3-compatible object storage for immutable RAW and derived images;
- a durable asynchronous task queue for processing;
- MLflow-compatible experiment/model tracking;
- CVAT-compatible detection, segmentation, and track annotation;
- a web API and review dashboard with role-based access and a complete audit trail;
- on-premises inference with store-and-forward operation when network access is interrupted.

The runnable MVP implements this boundary as a Node.js capture/control plane and
a versioned Python HTTP inference service. Node owns image QC, feature
extraction, persistence, alerts, and the operator UI. Python owns group-aware
training, artifact metadata, calibration, abstention, and classification.
Inference failures either stop processing or use the recorded classical
baseline according to an explicit deployment policy. The dependency-free
softmax model included in the repository validates this boundary; it is a
bootstrap artifact, not a substitute for the PyTorch vision models and local
biological validation required in later phases.

### 5.1 Core records

- `Species`: scientific name, leaf type, stock type, expected phenology.
- `Cohort`: species, seed lot/provenance, sowing date, treatment, block.
- `Tray`: stable tray ID, layout, cell dimensions.
- `Seedling`: tray cell identity and lifecycle state.
- `CaptureSession`: time, arm program, calibration version, environment, QC.
- `View`: image URI, camera settings, pose, quality flags.
- `Observation`: trait value, units, uncertainty, coverage, model version.
- `Finding`: syndrome/class, location mask/box, severity, confidence, evidence level.
- `Review`: expert decision, rationale, diagnostic sample/lab reference.
- `Alert`: rule, threshold, status, assignee, actions, and resolution.

Never overwrite raw captures, labels, or prior predictions. Corrections create new versions.

## 6. Model design

### 6.1 Stage A — deterministic geometry and image quality

1. Detect tray fiducials and recover camera pose.
2. Validate sharpness, exposure, color reference, and plant motion.
3. Register the tray and project its cell grid into every view.
4. Segment vegetation from background and assign visible pixels to candidate cells.
5. Produce view coverage and per-cell crop sets.

Retain a classical color/geometry baseline. It is valuable for detecting pipeline regressions even after learned segmentation is introduced.

### 6.2 Stage B — growth and morphology

- Train one shared vegetation/seedling segmentation backbone with species or leaf type as an input.
- Derive height from calibrated side/oblique silhouettes and multi-view geometry.
- Derive projected canopy area from the zenith mask.
- Fuse calibrated silhouettes into a coarse visual hull or point cloud for canopy-volume and lean proxies.
- Fit longitudinal growth curves per cohort using robust mixed-effects or hierarchical models.
- Alert on sustained deviation from the cohort trajectory, not on one noisy frame.
- Calibrate image traits against manual height and diameter measurements and a smaller destructive biomass sample. Keep only traits that meet repeatability and accuracy gates.

Do not make an end-to-end “good/bad growth” neural network the primary measurement path. Store physical or interpretable traits first, then apply nursery-approved thresholds.

### 6.3 Stage C — visible health

Use two linked models:

1. A lesion/symptom detector or segmenter that localizes chlorosis, necrosis, spots, wilting, deformation, and pest damage.
2. A species-conditioned classifier that combines the best visible views, symptom geometry, growth trajectory, and environmental context.

Aggregate evidence at the seedling-session level rather than treating 25 views as 25 independent samples. Calibrate probabilities and include an abstention threshold. A healthy-only embedding/anomaly model supplies `unknown_novel_pattern`; it does not assign a disease name.

### 6.4 Stage D — sticky-card pests

- Tile the high-resolution macro image with overlap.
- Use a small-object detector with a feature pyramid; Faster R-CNN/FPN is the literature-backed baseline.
- De-duplicate objects across tile borders.
- Return class counts, total count, count uncertainty, and change since the previous card.
- Separate target pests, beneficial insects, non-target insects, debris, and ambiguous objects.

### 6.5 Model selection protocol

For each task, benchmark one simple baseline and two pretrained deep models. Select the smallest model that:

1. passes the future-time holdout acceptance gate;
2. stays within 2% of the best macro-F1 or trait error;
3. meets batch latency;
4. has a deployment-compatible license;
5. supports probability calibration and reproducible export.

This prevents architecture novelty from displacing field reliability.

## 7. Local dataset and annotation program

### 7.1 Taxonomy workshop

Before labeling, a nursery manager, forest pathologist, entomologist, and ML lead define:

- the initial species and stock types;
- three to five actionable growth decisions;
- at most five visible disease/syndrome targets;
- at most five pest targets;
- severity scales and intervention thresholds;
- confusable abiotic stresses;
- evidence needed for a named diagnosis.

Classes without a different operational response should remain grouped in v1.

### 7.2 Data collection

Collect at least one complete production cycle, including different:

- species, seed lots/provenances, ages, phenological stages, and canopy densities;
- tray positions, treatments, irrigation states, and capture times;
- healthy plants, routine variation, abiotic stress, mechanical damage, and target outbreaks;
- symptom severities and presymptomatic/early/late time points where controlled challenge trials are permitted;
- clean, aging, crowded, and debris-contaminated sticky cards.

Initial evidence targets:

- at least 1,000 independently tracked healthy seedlings per leaf type across multiple trays and dates;
- at least 200 independently affected seedlings per named disease/syndrome across three or more biologically distinct events, where feasible;
- at least 1,000 annotated pest instances per target species across multiple cards and dates;
- weekly manual height measurements on at least 200 seedlings per leaf type;
- root-collar diameter on a visible, stratified subset;
- destructive fresh/dry biomass on a smaller, ethically and operationally acceptable subset;
- laboratory confirmation on all ambiguous cases and a stratified sample of apparent true positives and negatives.

These are starting targets, not proof of adequacy. Plot learning curves and expand until validation performance and confidence intervals stabilize. Multiple views of one seedling are one biological sample, not 25 independent samples.

### 7.3 Annotation rules

- Annotate tray/cell ownership, plant mask, visible symptom mask/box, syndrome, severity, pest box/class, and visibility/occlusion.
- Store scientific species names and controlled taxonomy IDs.
- Separate observation from diagnosis.
- Store annotator, reviewer, method, date, and evidence level.
- Double-review all named disease labels; calculate inter-rater agreement.
- Do not train from unverified web images as if they were local ground truth.

### 7.4 Leakage-safe splits

Never randomly split images. Group all views and dates from the same seedling together.

- Training: earlier cohorts/blocks.
- Validation: held-out trays and capture dates.
- Internal test: an unseen production block and later time window.
- Final prospective test: a future production cycle frozen before model tuning.
- Expansion test: a different physical nursery zone before site-wide rollout.

Report results per species, leaf type, age, severity, tray density, and capture quality, not only as one pooled score.

## 8. Acceptance tests and operating thresholds

### 8.1 Acquisition

- At least 98% of scheduled batch sessions pass automatic QC or are automatically rescanned.
- Median fiducial reprojection error is at most 1 pixel; 95th percentile is at most 2 pixels.
- Repeated scans of a static calibration plant vary by at most 3% for projected area and 5 mm for height.
- Every reported seedling has the minimum validated view-coverage score.

### 8.2 Growth

- Occupancy/emergence recall at least 98% and precision at least 98%.
- Height mean absolute error at most the greater of 10 mm or 5% of manually measured height.
- Projected canopy-area relative mean absolute error at most 10%.
- Growth-alert sensitivity at least 90% for manager-defined actionable deviations, with at most 0.5 false alerts per 100 seedlings per inspection.
- Root-collar diameter remains labeled experimental until error is at most the greater of 0.5 mm or 10%.

### 8.3 Disease and stress screening

- For each actionable target at the agreed severity: sensitivity at least 90% and precision at least 80% on the prospective test.
- Macro-F1 at least 0.80 across named classes; no class may be hidden by a high pooled accuracy.
- At least 95% of unfamiliar/low-quality examples are either rejected by QC, mapped to a syndrome/unknown class, or sent to review rather than assigned a high-confidence named diagnosis.
- Confidence calibration expected calibration error at most 0.05.
- A nursery expert signs off the false-negative review before operational use.

### 8.4 Pests

- Per-target detection recall at least 90% at the smallest actionable size.
- Macro-F1 at least 0.85 on cards from unseen dates.
- Count mean absolute percentage error at most 15% when a card contains at least 10 target insects; use absolute error for lower counts.
- Alert agreement with expert IPM decisions at least 90%.

### 8.5 Operational

- Results available within five minutes of batch completion.
- Offline capture continues safely and synchronizes without duplicate sessions.
- Every prediction is traceable to images, calibration, preprocessing, and model version.
- No treatment, disposal, or pesticide action is triggered without an authorized human decision in v1.

Failure to meet a named-condition threshold downgrades that condition to syndrome/anomaly screening; it does not delay useful growth monitoring.

## 9. Delivery phases

### Phase 0 — biological and operational definition (2–4 weeks)

- Run the taxonomy/decision workshop.
- Measure tray dimensions, plant envelope, target symptom size, required throughput, and current inspection workflow.
- Freeze v1 outcomes, labels, safety requirements, and acceptance thresholds.
- Build the annotation and lab-confirmation protocol.

**Exit:** signed target taxonomy, capture-cell requirements, ground-truth protocol, and test plan.

### Phase 1 — acquisition cell and repeatability (4–8 weeks)

- Build the rotating arm, two-elevation/zenith motion program, lighting enclosure, tray nest, fiducials, and safety controls.
- Implement capture metadata, image QC, calibration, and immutable storage.
- Perform GSD, focus, repeatability, plant-motion, full-tray versus spaced-batch, and 25-versus-49-view experiments.

**Exit:** at least 98% capture success and repeatability gates met on both leaf types.

### Phase 2 — growth MVP and prospective data collection (8–16 weeks, overlapping one production cycle)

- Implement tray/cell registration, segmentation, occupancy, height, area, color, coverage, and longitudinal cohort baselines.
- Collect paired manual and destructive measurements.
- Deploy a dashboard with trends, image evidence, and correction workflow.

**Exit:** growth and occupancy acceptance gates met on an unseen time window.

### Phase 3 — visible health and pest pilot (12–24 weeks, data-dependent)

- Train syndrome localization, local named-condition models, unknown detection, and sticky-card detection.
- Integrate expert review and laboratory results.
- Run shadow mode without using outputs for treatment decisions.

**Exit:** prospective thresholds met per class and expert false-negative review completed.

### Phase 4 — controlled operational pilot (8–12 weeks)

- Use the system for one nursery zone while retaining the existing inspection process.
- Measure labor saved, alert burden, lead time, missed cases, repeatability, and intervention agreement.
- Lock model/version rollback, monitoring, and incident procedures.

**Exit:** nursery manager, pathologist, entomologist, and engineering owner approve expansion.

### Phase 5 — expansion

- Add species or conditions one at a time with the same data and prospective-validation gates.
- Validate any multispectral or hyperspectral upgrade in a paired experiment against RGB and laboratory ground truth.
- Do not reuse thresholds across sites, seasons, or stock types without validation.

## 10. Principal risks and mitigations

| Risk | Mitigation |
|---|---|
| Interior seedlings are occluded. | Add high-oblique and zenith views, quantify coverage, use smaller/spaced batches for full inspection, and abstain when insufficient. |
| Seasonal color is mistaken for disease. | Calibrate color and condition baselines on species, provenance, age, season, and treatment. |
| Disease and abiotic stress look alike. | Detect syndrome first, incorporate time/environment, require expert/lab confirmation, and preserve unknown. |
| Public datasets inflate apparent accuracy. | Use them only for pretraining; test prospectively on local rig images with grouped splits. |
| Rare disease classes lack data. | Use active learning, expert review, approved controlled challenge trials, and keep unsupported classes at syndrome level. |
| Tiny pests are unresolved in batch images. | Use the same camera at a macro sticky-card station with target GSD and tiled inference. |
| Plant motion breaks reconstruction. | Step-and-shoot, vibration settling, pause fans/irrigation, and automatic motion QC. |
| Model drift follows growth stage or maintenance. | Monitor input/trait distributions and QC, retain cohort-specific calibration, and trigger review rather than silent retraining. |
| A high-confidence model causes unsafe action. | Human authorization remains mandatory; display evidence, uncertainty, and model version. |

## 11. Definition of a successful first system

The first system is successful when it can repeatedly scan priority Idesia and Japanese larch batches, map reliable measurements back to tray cells, quantify growth with agreed error, identify visible actionable abnormalities with controlled false alerts, count priority sticky-card pests, and make uncertainty obvious. It should reduce routine inspection effort and find problems earlier without presenting a camera prediction as laboratory diagnosis.
