import { buildApp } from "./app.js";

const app = await buildApp();
const { host, port } = app.system.config;

try {
  await app.listen({ host, port });
  app.log.info(`Seedlings Vision is available at http://${host}:${port}`);
} catch (error) {
  app.log.error(error);
  process.exit(1);
}

