import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

export class ImageStorage {
  constructor(imageDir) {
    this.imageDir = imageDir;
  }

  async initialize() {
    await fs.mkdir(this.imageDir, { recursive: true });
  }

  async save({ sessionId, sequenceIndex, extension = "jpg", buffer }) {
    const safeExtension = extension.replace(/[^a-z0-9]/gi, "").toLowerCase() || "jpg";
    const digest = crypto.createHash("sha256").update(buffer).digest("hex").slice(0, 12);
    const directory = path.join(this.imageDir, String(sessionId));
    await fs.mkdir(directory, { recursive: true });
    const filename = `${String(sequenceIndex).padStart(3, "0")}-${digest}.${safeExtension}`;
    const target = path.join(directory, filename);
    await fs.writeFile(target, buffer, { flag: "wx" });
    return target;
  }
}

