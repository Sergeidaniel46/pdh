import sharp from "sharp";

function round(value, digits = 4) {
  return Number(value.toFixed(digits));
}

export async function inspectImage(buffer, thresholds) {
  const image = sharp(buffer, { failOn: "warning" });
  const metadata = await image.metadata();
  const { data, info } = await image
    .clone()
    .resize({ width: 320, height: 240, fit: "inside", withoutEnlargement: true })
    .removeAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  let lumaTotal = 0;
  let clipped = 0;
  let edgeTotal = 0;
  let edgeCount = 0;
  const channels = info.channels;
  const luminance = new Float32Array(info.width * info.height);

  for (let pixel = 0; pixel < info.width * info.height; pixel += 1) {
    const offset = pixel * channels;
    const r = data[offset];
    const g = data[offset + 1] ?? r;
    const b = data[offset + 2] ?? r;
    const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    luminance[pixel] = luma;
    lumaTotal += luma;
    if (r <= 2 || g <= 2 || b <= 2 || r >= 253 || g >= 253 || b >= 253) {
      clipped += 1;
    }
  }

  for (let y = 1; y < info.height; y += 1) {
    for (let x = 1; x < info.width; x += 1) {
      const index = y * info.width + x;
      edgeTotal += Math.abs(luminance[index] - luminance[index - 1]);
      edgeTotal += Math.abs(luminance[index] - luminance[index - info.width]);
      edgeCount += 2;
    }
  }

  const meanLuma = lumaTotal / luminance.length;
  const clippedFraction = clipped / luminance.length;
  const sharpness = edgeCount > 0 ? edgeTotal / edgeCount : 0;
  const reasons = [];

  if ((metadata.width ?? 0) < thresholds.minimumWidth) reasons.push("width_below_minimum");
  if ((metadata.height ?? 0) < thresholds.minimumHeight) reasons.push("height_below_minimum");
  if (meanLuma < thresholds.minimumLuma) reasons.push("underexposed");
  if (meanLuma > thresholds.maximumLuma) reasons.push("overexposed");
  if (clippedFraction > thresholds.maximumClippedFraction) reasons.push("excessive_clipping");
  if (sharpness < thresholds.minimumSharpness) reasons.push("image_not_sharp");

  return {
    pass: reasons.length === 0,
    reasons,
    width: metadata.width ?? info.width,
    height: metadata.height ?? info.height,
    meanLuma: round(meanLuma),
    clippedFraction: round(clippedFraction),
    sharpness: round(sharpness)
  };
}

