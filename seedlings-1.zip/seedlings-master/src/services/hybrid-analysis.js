import {
  baselinePredictions,
  extractSessionFeatures,
  markQcFailed,
  persistAnalysisResult
} from "./baseline-analysis.js";

export async function analyzeHybridSession({
  repository,
  sessionId,
  baselineModelVersion,
  inferenceClient,
  inferenceMode
}) {
  if (!inferenceClient) {
    const extraction = await extractSessionFeatures({ repository, sessionId });
    if (extraction.qcFailed) {
      return markQcFailed({ repository, extraction, modelVersion: baselineModelVersion });
    }
    return persistAnalysisResult({
      repository,
      extraction,
      predictions: baselinePredictions(extraction),
      modelVersion: baselineModelVersion,
      analysisEngine: "baseline"
    });
  }

  const extraction = await extractSessionFeatures({ repository, sessionId });
  if (extraction.qcFailed) {
    return markQcFailed({ repository, extraction, modelVersion: baselineModelVersion });
  }

  try {
    const result = await inferenceClient.predict(extraction);
    return persistAnalysisResult({
      repository,
      extraction,
      predictions: result.predictions,
      modelVersion: result.modelVersion,
      analysisEngine: "python_ml"
    });
  } catch (error) {
    if (inferenceMode === "required") {
      repository.clearAnalysis(sessionId);
      repository.updateSession(sessionId, {
        status: "analysis_failed",
        qcPassRate: extraction.passRate,
        processedAt: new Date().toISOString(),
        modelVersion: "ml-unavailable"
      });
      throw error;
    }
    return {
      ...persistAnalysisResult({
        repository,
        extraction,
        predictions: baselinePredictions(extraction),
        modelVersion: baselineModelVersion,
        analysisEngine: "baseline_fallback"
      }),
      fallbackReason: error.message
    };
  }
}
