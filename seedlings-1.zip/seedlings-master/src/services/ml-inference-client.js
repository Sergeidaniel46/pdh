const CONTRACT_VERSION = "1.0";

export class MlInferenceError extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "MlInferenceError";
  }
}

function validateFinding(finding, cellKey) {
  if (finding == null) return null;
  if (
    typeof finding.category !== "string"
    || typeof finding.syndrome !== "string"
    || !Number.isInteger(finding.severity)
    || finding.severity < 0
    || finding.severity > 4
    || !Number.isFinite(finding.confidence)
    || finding.confidence < 0
    || finding.confidence > 1
  ) {
    throw new MlInferenceError(`Invalid finding returned for cell ${cellKey}`);
  }
  return {
    category: finding.category,
    syndrome: finding.syndrome,
    suspectedClass: finding.suspectedClass ?? null,
    severity: finding.severity,
    confidence: finding.confidence,
    evidenceLevel: finding.evidenceLevel ?? "screening_only",
    details: finding.details && typeof finding.details === "object" ? finding.details : {}
  };
}

export class MlInferenceClient {
  constructor({ url, timeoutMs = 10_000 }) {
    this.url = url.replace(/\/+$/, "");
    this.timeoutMs = timeoutMs;
  }

  async predict(extraction) {
    const cells = extraction.aggregates.map((item) => ({
      rowIndex: item.seedling.row_index,
      columnIndex: item.seedling.column_index,
      features: {
        occupancy: item.occupancy,
        heightMm: item.heightMm,
        heightRatio: extraction.heightReference
          ? item.heightMm / extraction.heightReference
          : 0,
        canopyAreaMm2: item.canopyAreaMm2,
        greenFraction: item.greenFraction,
        chloroticFraction: item.chloroticFraction,
        necroticFraction: item.necroticFraction,
        coverage: item.coverage
      }
    }));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
    let response;
    try {
      response = await fetch(`${this.url}/v1/predict`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          contractVersion: CONTRACT_VERSION,
          session: {
            id: extraction.session.id,
            scientificName: extraction.session.scientific_name,
            scientificNameAlias: extraction.session.scientific_name_alias,
            leafType: extraction.session.leaf_type,
            capturedAt: extraction.session.captured_at
          },
          cells
        }),
        signal: controller.signal
      });
    } catch (error) {
      const reason = error.name === "AbortError" ? "request timed out" : error.message;
      throw new MlInferenceError(`ML inference unavailable: ${reason}`, { cause: error });
    } finally {
      clearTimeout(timeout);
    }

    let body;
    try {
      body = await response.json();
    } catch (error) {
      throw new MlInferenceError("ML inference returned invalid JSON", { cause: error });
    }
    if (!response.ok) {
      throw new MlInferenceError(
        `ML inference failed with HTTP ${response.status}: ${body.error ?? "unknown error"}`
      );
    }
    if (
      body.contractVersion !== CONTRACT_VERSION
      || typeof body.modelVersion !== "string"
      || !Array.isArray(body.predictions)
    ) {
      throw new MlInferenceError("ML inference response does not match contract 1.0");
    }

    const expected = new Set(cells.map((cell) => `${cell.rowIndex}:${cell.columnIndex}`));
    const returned = new Set();
    const predictions = body.predictions.map((prediction) => {
      if (
        !Number.isInteger(prediction.rowIndex)
        || !Number.isInteger(prediction.columnIndex)
      ) {
        throw new MlInferenceError("ML inference returned non-integer cell coordinates");
      }
      const key = `${prediction.rowIndex}:${prediction.columnIndex}`;
      if (!expected.has(key) || returned.has(key)) {
        throw new MlInferenceError(`Unexpected or duplicate ML prediction for cell ${key}`);
      }
      returned.add(key);
      return {
        rowIndex: prediction.rowIndex,
        columnIndex: prediction.columnIndex,
        finding: validateFinding(prediction.finding, key)
      };
    });
    if (returned.size !== expected.size) {
      throw new MlInferenceError(
        `ML inference returned ${returned.size} predictions for ${expected.size} cells`
      );
    }
    return { modelVersion: body.modelVersion, predictions };
  }
}
