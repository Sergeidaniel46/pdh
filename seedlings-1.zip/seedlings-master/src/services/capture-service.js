import path from "node:path";
import { inspectImage } from "./image-qc.js";
import { analyzeHybridSession } from "./hybrid-analysis.js";

export class CaptureService {
  constructor({ repository, storage, config, inferenceClient }) {
    this.repository = repository;
    this.storage = storage;
    this.config = config;
    this.inferenceClient = inferenceClient;
  }

  async createSession({ trayId, capturedAt, captureProgram }) {
    const tray = this.repository.getTray(trayId);
    if (!tray) throw new Error(`Tray ${trayId} does not exist`);
    return this.repository.createSession({
      trayId,
      capturedAt: capturedAt ?? new Date().toISOString(),
      captureProgram: captureProgram ?? "orbit-25-v1"
    });
  }

  async addView({ sessionId, sequenceIndex, angleDeg, elevation, mmPerPixel, buffer, filename }) {
    const session = this.repository.getSession(sessionId);
    if (!session) throw new Error(`Capture session ${sessionId} does not exist`);
    const extension = path.extname(filename ?? "").slice(1) || "jpg";
    const imagePath = await this.storage.save({
      sessionId,
      sequenceIndex,
      extension,
      buffer
    });
    const viewId = this.repository.addView({
      sessionId,
      sequenceIndex,
      angleDeg,
      elevation,
      mmPerPixel,
      imagePath
    });
    const qc = await inspectImage(buffer, this.config.qc);
    this.repository.updateViewQc(viewId, qc);
    return { id: viewId, imagePath, qc };
  }

  async process(sessionId) {
    return analyzeHybridSession({
      repository: this.repository,
      sessionId,
      baselineModelVersion: this.config.modelVersion,
      inferenceClient: this.inferenceClient,
      inferenceMode: this.config.ml.mode
    });
  }
}
