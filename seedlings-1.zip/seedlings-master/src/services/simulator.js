import sharp from "sharp";

function seededRandom(seed) {
  let state = seed >>> 0;
  return () => {
    state = (state * 1664525 + 1013904223) >>> 0;
    return state / 0x1_0000_0000;
  };
}

function heartLeaf({ cx, cy, rx, ry, rotation, color }) {
  return `
    <path
      d="M ${cx} ${cy + ry}
         C ${cx - rx * 1.18} ${cy + ry * 0.3}, ${cx - rx} ${cy - ry * 0.82}, ${cx} ${cy - ry * 0.14}
         C ${cx + rx} ${cy - ry * 0.82}, ${cx + rx * 1.18} ${cy + ry * 0.3}, ${cx} ${cy + ry} Z"
      transform="rotate(${rotation} ${cx} ${cy})"
      fill="${color}"
    />
  `;
}

function plantSvg({ x, y, width, height, leafType, scientificName, condition, phase }) {
  if (condition === "missing") return "";
  const healthy = "#3f8f45";
  const secondary = "#69a84f";
  const chlorotic = "#d0b94c";
  const necrotic = "#87502e";
  const color = condition === "chlorosis" ? chlorotic : condition === "necrosis" ? necrotic : healthy;
  const accent = condition === "chlorosis" ? "#e5d561" : condition === "necrosis" ? "#a2673d" : secondary;
  const stemX = x + width / 2;
  const baseY = y + height * 0.88;
  const topY = y + height * 0.15;
  const sway = Math.sin(phase) * width * 0.05;
  let shapes = `<path d="M ${stemX} ${baseY} Q ${stemX + sway} ${y + height * 0.5} ${stemX + sway} ${topY}" stroke="#536f35" stroke-width="${Math.max(3, width * 0.035)}" fill="none"/>`;

  if (scientificName === "Idesia polycarpa") {
    for (let level = 0; level < 5; level += 1) {
      const yy = topY + level * height * 0.14;
      const direction = level % 2 === 0 ? 1 : -1;
      const leafX = stemX + direction * width * (0.16 + level * 0.012) + sway;
      const oppositeX = stemX - direction * width * 0.13 + sway;
      shapes += `<path d="M ${stemX + sway} ${yy + height * 0.035} L ${leafX} ${yy}" stroke="#536f35" stroke-width="${Math.max(2, width * 0.018)}"/>`;
      shapes += `<path d="M ${stemX + sway} ${yy + height * 0.055} L ${oppositeX} ${yy + height * 0.035}" stroke="#536f35" stroke-width="${Math.max(2, width * 0.018)}"/>`;
      shapes += heartLeaf({
        cx: leafX,
        cy: yy,
        rx: width * (0.13 + level * 0.008),
        ry: height * 0.065,
        rotation: direction * -14,
        color: level % 2 ? accent : color
      });
      shapes += heartLeaf({
        cx: oppositeX,
        cy: yy + height * 0.035,
        rx: width * (0.115 + level * 0.006),
        ry: height * 0.058,
        rotation: direction * 16,
        color: level % 2 ? color : accent
      });
    }
  } else if (leafType === "needle") {
    for (let level = 0; level < 6; level += 1) {
      const yy = topY + level * height * 0.11;
      const span = width * (0.20 + level * 0.045);
      for (let branch = -2; branch <= 2; branch += 1) {
        const dx = branch * span * 0.35;
        const branchX = stemX + dx;
        const branchY = yy + height * 0.075;
        const branchColor = branch % 2 === 0 ? color : accent;
        shapes += `<path d="M ${stemX + sway * (1 - level / 8)} ${yy} L ${branchX} ${branchY}" stroke="${branchColor}" stroke-width="${Math.max(2, width * 0.024)}" stroke-linecap="round"/>`;
        if (scientificName === "Larix kaempferi" && branch !== 0) {
          for (let needle = -2; needle <= 2; needle += 1) {
            const needleOffset = needle * width * 0.025;
            shapes += `<path d="M ${branchX} ${branchY} L ${branchX + needleOffset} ${branchY + height * (needle % 2 === 0 ? 0.045 : -0.035)}" stroke="${branchColor}" stroke-width="${Math.max(1.5, width * 0.014)}" stroke-linecap="round"/>`;
          }
        }
      }
    }
  } else {
    for (let level = 0; level < 5; level += 1) {
      const yy = topY + level * height * 0.13;
      const direction = level % 2 === 0 ? 1 : -1;
      const leafWidth = width * (0.24 + level * 0.018);
      shapes += `<ellipse cx="${stemX + direction * width * 0.16 + sway}" cy="${yy}" rx="${leafWidth}" ry="${height * 0.065}" transform="rotate(${direction * -18} ${stemX + direction * width * 0.16 + sway} ${yy})" fill="${level % 2 ? accent : color}"/>`;
      shapes += `<ellipse cx="${stemX - direction * width * 0.13 + sway}" cy="${yy + height * 0.045}" rx="${leafWidth * 0.85}" ry="${height * 0.06}" transform="rotate(${direction * 20} ${stemX - direction * width * 0.13 + sway} ${yy + height * 0.045})" fill="${level % 2 ? color : accent}"/>`;
    }
  }
  return shapes;
}

function renderBatchSvg({ tray, angleDeg, elevation, random, scanIndex }) {
  const width = 1200;
  const height = 900;
  const cellWidth = width / tray.columns;
  const cellHeight = height / tray.rows;
  const viewPhase = (angleDeg ?? 0) * Math.PI / 180;
  let plants = "";

  for (let row = 0; row < tray.rows; row += 1) {
    for (let column = 0; column < tray.columns; column += 1) {
      const index = row * tray.columns + column;
      let condition = "healthy";
      if (index === 2) condition = "chlorosis";
      if (index === 7) condition = "necrosis";
      if (index === 10) condition = "missing";
      const variation = 0.82 + random() * 0.16;
      const stunted = index === 4 ? 0.48 : 1;
      const growth = 1 + scanIndex * 0.035;
      const plantHeight = cellHeight * 0.78 * variation * stunted * growth;
      const plantWidth = cellWidth * (tray.leaf_type === "needle" ? 0.48 : 0.62);
      const x = column * cellWidth + (cellWidth - plantWidth) / 2;
      const y = row * cellHeight + cellHeight - plantHeight - cellHeight * 0.04;
      plants += plantSvg({
        x,
        y,
        width: plantWidth,
        height: plantHeight,
        leafType: tray.leaf_type,
        scientificName: tray.scientific_name,
        condition,
        phase: viewPhase + index * 0.23
      });
    }
  }

  const elevationLabel = elevation.toUpperCase();
  return `
    <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
      <rect width="100%" height="100%" fill="#d9d5ca"/>
      <rect x="8" y="8" width="${width - 16}" height="${height - 16}" rx="22" fill="#c8c2b5" stroke="#343a36" stroke-width="8"/>
      ${Array.from({ length: tray.rows - 1 }, (_, index) => `<line x1="12" y1="${(index + 1) * cellHeight}" x2="${width - 12}" y2="${(index + 1) * cellHeight}" stroke="#9b9488" stroke-width="3"/>`).join("")}
      ${Array.from({ length: tray.columns - 1 }, (_, index) => `<line x1="${(index + 1) * cellWidth}" y1="12" x2="${(index + 1) * cellWidth}" y2="${height - 12}" stroke="#9b9488" stroke-width="3"/>`).join("")}
      ${plants}
      <g font-family="sans-serif" font-size="24" fill="#242824">
        <rect x="22" y="20" width="260" height="44" rx="6" fill="#f4f1e9" opacity="0.92"/>
        <text x="34" y="50">${tray.tray_code} · ${elevationLabel} · ${angleDeg ?? 0}°</text>
      </g>
      <g>
        <rect x="${width - 152}" y="22" width="120" height="34" fill="#f2f2ed"/>
        <rect x="${width - 152}" y="22" width="40" height="34" fill="#ffffff"/>
        <rect x="${width - 112}" y="22" width="40" height="34" fill="#808080"/>
        <rect x="${width - 72}" y="22" width="40" height="34" fill="#151515"/>
      </g>
    </svg>
  `;
}

export async function simulateCapture({ captureService, repository, trayId, seed = 42, scanIndex = 0, capturedAt }) {
  const tray = repository.getTray(trayId);
  if (!tray) throw new Error(`Tray ${trayId} does not exist`);
  const sessionId = await captureService.createSession({
    trayId,
    capturedAt: capturedAt ?? new Date().toISOString(),
    captureProgram: "orbit-25-v1"
  });
  const random = seededRandom(seed);
  const views = [];
  let sequenceIndex = 0;

  for (const elevation of ["low", "high"]) {
    for (let angleDeg = 0; angleDeg < 360; angleDeg += 30) {
      const svg = renderBatchSvg({ tray, angleDeg, elevation, random, scanIndex });
      const buffer = await sharp(Buffer.from(svg)).png().toBuffer();
      views.push(await captureService.addView({
        sessionId,
        sequenceIndex,
        angleDeg,
        elevation,
        mmPerPixel: 0.5,
        buffer,
        filename: `${elevation}-${angleDeg}.png`
      }));
      sequenceIndex += 1;
    }
  }

  const topSvg = renderBatchSvg({ tray, angleDeg: 0, elevation: "zenith", random, scanIndex });
  const topBuffer = await sharp(Buffer.from(topSvg)).png().toBuffer();
  views.push(await captureService.addView({
    sessionId,
    sequenceIndex,
    angleDeg: 0,
    elevation: "zenith",
    mmPerPixel: 0.5,
    buffer: topBuffer,
    filename: "zenith.png"
  }));

  const analysis = await captureService.process(sessionId);
  return { sessionId, views: views.length, analysis };
}
