import fs from "node:fs/promises";
import sharp from "sharp";

function median(values) {
  if (values.length === 0) return null;
  const ordered = [...values].sort((a, b) => a - b);
  const middle = Math.floor(ordered.length / 2);
  return ordered.length % 2 === 0
    ? (ordered[middle - 1] + ordered[middle]) / 2
    : ordered[middle];
}

function mean(values) {
  return values.length === 0 ? null : values.reduce((sum, value) => sum + value, 0) / values.length;
}

function standardDeviation(values) {
  if (values.length < 2) return 0;
  const average = mean(values);
  return Math.sqrt(mean(values.map((value) => (value - average) ** 2)));
}

function round(value, digits = 4) {
  if (value == null || !Number.isFinite(value)) return null;
  return Number(value.toFixed(digits));
}

async function analyzeCellGrid(imagePath, rows, columns, mmPerPixel) {
  const buffer = await fs.readFile(imagePath);
  const { data, info } = await sharp(buffer)
    .resize({ width: 960, height: 720, fit: "fill" })
    .removeAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const cells = [];
  const cellWidth = Math.floor(info.width / columns);
  const cellHeight = Math.floor(info.height / rows);
  const scaleAdjustment = (info.width / 960);
  const adjustedMmPerPixel = (mmPerPixel ?? 0.5) / scaleAdjustment;

  for (let row = 0; row < rows; row += 1) {
    for (let column = 0; column < columns; column += 1) {
      const xStart = column * cellWidth;
      const xEnd = column === columns - 1 ? info.width : (column + 1) * cellWidth;
      const yStart = row * cellHeight;
      const yEnd = row === rows - 1 ? info.height : (row + 1) * cellHeight;
      const totalPixels = (xEnd - xStart) * (yEnd - yStart);
      let plantPixels = 0;
      let greenPixels = 0;
      let chloroticPixels = 0;
      let necroticPixels = 0;
      let minY = yEnd;
      let maxY = yStart;

      for (let y = yStart; y < yEnd; y += 1) {
        for (let x = xStart; x < xEnd; x += 1) {
          const offset = (y * info.width + x) * info.channels;
          const r = data[offset];
          const g = data[offset + 1];
          const b = data[offset + 2];
          const chroma = Math.max(r, g, b) - Math.min(r, g, b);
          const green = g > 42 && g > r * 1.04 && g > b * 1.08 && chroma > 15;
          const chlorotic = r > 75 && g > 75 && b < 145 && chroma > 22
            && r / Math.max(g, 1) > 0.72 && r / Math.max(g, 1) < 1.35;
          const necrotic = r > 55 && r > g * 1.05 && g > b * 0.82 && b < 110 && chroma > 25;
          if (green || chlorotic || necrotic) {
            plantPixels += 1;
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            if (green) greenPixels += 1;
            else if (chlorotic) chloroticPixels += 1;
            else necroticPixels += 1;
          }
        }
      }

      const heightPixels = plantPixels > 0 ? maxY - minY + 1 : 0;
      cells.push({
        row,
        column,
        occupancyFraction: plantPixels / totalPixels,
        plantPixels,
        heightMm: heightPixels * adjustedMmPerPixel,
        areaMm2: plantPixels * adjustedMmPerPixel ** 2,
        greenFraction: plantPixels > 0 ? greenPixels / plantPixels : 0,
        chloroticFraction: plantPixels > 0 ? chloroticPixels / plantPixels : 0,
        necroticFraction: plantPixels > 0 ? necroticPixels / plantPixels : 0
      });
    }
  }
  return cells;
}

function findingForCell(metrics, heightReference) {
  if (metrics.occupancy < 0.012) {
    return {
      category: "growth",
      syndrome: "missing_or_dead",
      severity: 4,
      confidence: 0.96,
      details: { occupancy: metrics.occupancy }
    };
  }
  if (metrics.necroticFraction >= 0.18) {
    return {
      category: "visible_abiotic_or_unknown_stress",
      syndrome: "browning_necrosis",
      severity: metrics.necroticFraction >= 0.35 ? 3 : 2,
      confidence: Math.min(0.97, 0.7 + metrics.necroticFraction),
      details: { necroticFraction: metrics.necroticFraction }
    };
  }
  if (metrics.chloroticFraction >= 0.22) {
    return {
      category: "visible_abiotic_or_unknown_stress",
      syndrome: "chlorosis",
      severity: metrics.chloroticFraction >= 0.4 ? 3 : 2,
      confidence: Math.min(0.95, 0.65 + metrics.chloroticFraction),
      details: { chloroticFraction: metrics.chloroticFraction }
    };
  }
  if (heightReference && metrics.heightMm < heightReference * 0.62) {
    return {
      category: "growth",
      syndrome: "stunting",
      severity: 2,
      confidence: 0.82,
      details: { heightMm: metrics.heightMm, cohortMedianHeightMm: heightReference }
    };
  }
  if (metrics.coverage < 0.65) {
    return {
      category: "quality_control",
      syndrome: "insufficient_view",
      severity: 1,
      confidence: 1,
      details: { coverage: metrics.coverage }
    };
  }
  return null;
}

export async function extractSessionFeatures({ repository, sessionId }) {
  const session = repository.getSession(sessionId);
  if (!session) throw new Error(`Capture session ${sessionId} does not exist`);
  const seedlings = repository.getSeedlings(session.tray_id);
  const views = repository.getViews(sessionId);
  const passedViews = views.filter((view) => view.qc_status === "passed");
  const passRate = views.length > 0 ? passedViews.length / views.length : 0;

  if (views.length === 0) throw new Error("Capture session has no views");
  if (passRate < 0.6) {
    return { session, passRate, qcFailed: true, aggregates: [], heightReference: null };
  }

  const analyzedViews = [];
  for (const view of passedViews) {
    analyzedViews.push({
      view,
      cells: await analyzeCellGrid(
        view.image_path,
        session.rows,
        session.columns,
        view.mm_per_pixel
      )
    });
  }

  const byCoordinate = new Map();
  for (const seedling of seedlings) {
    byCoordinate.set(`${seedling.row_index}:${seedling.column_index}`, {
      seedling,
      samples: []
    });
  }

  for (const analyzed of analyzedViews) {
    for (const cell of analyzed.cells) {
      const record = byCoordinate.get(`${cell.row}:${cell.column}`);
      record.samples.push({ ...cell, elevation: analyzed.view.elevation });
    }
  }

  const aggregates = [];
  for (const { seedling, samples } of byCoordinate.values()) {
    const side = samples.filter((sample) => sample.elevation === "low" || sample.elevation === "high");
    const top = samples.filter((sample) => sample.elevation === "zenith");
    const occupancyValues = samples.map((sample) => sample.occupancyFraction);
    const heightValues = side.map((sample) => sample.heightMm).filter((value) => value > 0);
    const areaValues = (top.length > 0 ? top : samples).map((sample) => sample.areaMm2);
    const coverage = samples.length / 25;
    const heightMm = median(heightValues) ?? 0;
    const canopyAreaMm2 = median(areaValues) ?? 0;

    aggregates.push({
      seedling,
      occupancy: Math.max(...occupancyValues, 0),
      heightMm,
      heightUncertainty: standardDeviation(heightValues),
      canopyAreaMm2,
      areaUncertainty: standardDeviation(areaValues),
      greenFraction: mean(samples.map((sample) => sample.greenFraction)) ?? 0,
      chloroticFraction: mean(samples.map((sample) => sample.chloroticFraction)) ?? 0,
      necroticFraction: mean(samples.map((sample) => sample.necroticFraction)) ?? 0,
      coverage
    });
  }

  const occupiedHeights = aggregates
    .filter((item) => item.occupancy >= 0.012 && item.heightMm > 0)
    .map((item) => item.heightMm);
  const heightReference = median(occupiedHeights);

  return {
    session,
    passRate,
    qcFailed: false,
    aggregates,
    heightReference
  };
}

export function baselinePredictions(extraction) {
  return extraction.aggregates.map((item) => ({
    rowIndex: item.seedling.row_index,
    columnIndex: item.seedling.column_index,
    finding: findingForCell(item, extraction.heightReference)
  }));
}

export function markQcFailed({ repository, extraction, modelVersion }) {
  repository.clearAnalysis(extraction.session.id);
  repository.updateSession(extraction.session.id, {
    status: "qc_failed",
    qcPassRate: extraction.passRate,
    processedAt: new Date().toISOString(),
    modelVersion
  });
  return {
    sessionId: extraction.session.id,
    status: "qc_failed",
    passRate: round(extraction.passRate),
    observations: 0,
    findings: 0,
    alerts: 0,
    modelVersion,
    analysisEngine: "quality_control"
  };
}

export function persistAnalysisResult({
  repository,
  extraction,
  predictions,
  modelVersion,
  analysisEngine
}) {
  const sessionId = extraction.session.id;
  const predictionByCell = new Map();
  for (const prediction of predictions) {
    const key = `${prediction.rowIndex}:${prediction.columnIndex}`;
    if (predictionByCell.has(key)) throw new Error(`Duplicate prediction for cell ${key}`);
    predictionByCell.set(key, prediction);
  }

  repository.clearAnalysis(sessionId);
  let observationCount = 0;
  let findingCount = 0;
  let alertCount = 0;

  for (const item of extraction.aggregates) {
    const observations = [
      ["occupancy_fraction", item.occupancy, "ratio", 0],
      ["height", item.heightMm, "mm", item.heightUncertainty],
      ["projected_canopy_area", item.canopyAreaMm2, "mm2", item.areaUncertainty],
      ["green_fraction", item.greenFraction, "ratio", null],
      ["chlorotic_fraction", item.chloroticFraction, "ratio", null],
      ["necrotic_fraction", item.necroticFraction, "ratio", null],
      ["view_coverage", item.coverage, "ratio", null]
    ];
    for (const [metric, value, unit, uncertainty] of observations) {
      repository.addObservation({
        sessionId,
        seedlingId: item.seedling.id,
        metric,
        value: round(value),
        unit,
        uncertainty: round(uncertainty),
        coverage: round(item.coverage),
        modelVersion
      });
      observationCount += 1;
    }

    const previousHeight = repository.getPreviousObservation(item.seedling.id, "height", sessionId);
    if (previousHeight) {
      const dayDelta = (
        new Date(extraction.session.captured_at).getTime()
        - new Date(previousHeight.captured_at).getTime()
      ) / 86_400_000;
      if (dayDelta > 0.1) {
        repository.addObservation({
          sessionId,
          seedlingId: item.seedling.id,
          metric: "height_growth_rate",
          value: round((item.heightMm - previousHeight.value) / dayDelta),
          unit: "mm/day",
          uncertainty: round(item.heightUncertainty),
          coverage: round(item.coverage),
          modelVersion
        });
        observationCount += 1;
      }
    }

    const key = `${item.seedling.row_index}:${item.seedling.column_index}`;
    const finding = predictionByCell.get(key)?.finding ?? null;
    if (finding) {
      const findingId = repository.addFinding({
        sessionId,
        seedlingId: item.seedling.id,
        category: finding.category,
        syndrome: finding.syndrome,
        suspectedClass: finding.suspectedClass,
        severity: finding.severity,
        confidence: finding.confidence,
        evidenceLevel: finding.evidenceLevel,
        details: finding.details
      });
      findingCount += 1;
      if (finding.severity >= 2 && finding.confidence >= 0.75) {
        repository.addAlert({
          findingId,
          sessionId,
          severity: finding.severity,
          message: `${finding.syndrome.replaceAll("_", " ")} at cell ${item.seedling.row_index + 1}:${item.seedling.column_index + 1}`,
          createdAt: new Date().toISOString()
        });
        alertCount += 1;
      }
    }
  }

  repository.updateSession(sessionId, {
    status: "processed",
    qcPassRate: extraction.passRate,
    processedAt: new Date().toISOString(),
    modelVersion
  });

  return {
    sessionId,
    status: "processed",
    passRate: round(extraction.passRate),
    observations: observationCount,
    findings: findingCount,
    alerts: alertCount,
    modelVersion,
    analysisEngine
  };
}

export async function analyzeSession({ repository, sessionId, modelVersion }) {
  const extraction = await extractSessionFeatures({ repository, sessionId });
  if (extraction.qcFailed) {
    return markQcFailed({ repository, extraction, modelVersion });
  }
  return persistAnalysisResult({
    repository,
    extraction,
    predictions: baselinePredictions(extraction),
    modelVersion,
    analysisEngine: "baseline"
  });
}
