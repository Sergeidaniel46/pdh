import path from "node:path";
import Fastify from "fastify";
import multipart from "@fastify/multipart";
import fastifyStatic from "@fastify/static";
import { createConfig } from "./config.js";
import { createDatabase, seedDemoData } from "./db.js";
import { Repository } from "./repository.js";
import { ImageStorage } from "./services/storage.js";
import { CaptureService } from "./services/capture-service.js";
import { MlInferenceClient } from "./services/ml-inference-client.js";
import { simulateCapture } from "./services/simulator.js";
import { openApiDocument } from "./openapi.js";

function integer(value, name) {
  const parsed = Number(value);
  if (!Number.isInteger(parsed)) throw new Error(`${name} must be an integer`);
  return parsed;
}

function numberOrNull(value) {
  if (value == null || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function sendError(reply, error, statusCode = 400) {
  reply.code(statusCode).send({ error: error.message });
}

export async function buildApp(overrides = {}) {
  const config = createConfig(overrides);
  const app = Fastify({ logger: config.logger });
  const db = createDatabase(config.databasePath);
  seedDemoData(db);
  const repository = new Repository(db);
  const storage = new ImageStorage(config.imageDir);
  await storage.initialize();
  const inferenceClient = config.ml.url ? new MlInferenceClient(config.ml) : null;
  const captureService = new CaptureService({
    repository,
    storage,
    config,
    inferenceClient
  });

  app.decorate("system", { config, db, repository, captureService, inferenceClient });
  await app.register(multipart, {
    limits: { fileSize: 30 * 1024 * 1024, files: 1, fields: 10 }
  });
  await app.register(fastifyStatic, {
    root: config.publicDir,
    prefix: "/"
  });

  app.get("/api/health", async () => ({
    status: "ok",
    modelVersion: config.modelVersion,
    inference: {
      configured: Boolean(config.ml.url),
      mode: config.ml.mode
    },
    time: new Date().toISOString()
  }));
  app.get("/api/openapi.json", async () => openApiDocument);
  app.get("/api/dashboard", async () => repository.getDashboard());
  app.get("/api/species", async () => repository.listSpecies());
  app.get("/api/cohorts", async () => repository.listCohorts());
  app.get("/api/trays", async () => repository.listTrays());
  app.get("/api/sessions", async (request) => {
    const limit = Math.min(100, Math.max(1, Number(request.query?.limit ?? 20)));
    return repository.listSessions(limit);
  });
  app.get("/api/sessions/:sessionId", async (request, reply) => {
    const detail = repository.getSessionDetail(integer(request.params.sessionId, "sessionId"));
    if (!detail) return reply.code(404).send({ error: "Session not found" });
    return detail;
  });

  app.post("/api/capture-sessions", async (request, reply) => {
    try {
      const sessionId = await captureService.createSession({
        trayId: integer(request.body?.trayId, "trayId"),
        capturedAt: request.body?.capturedAt,
        captureProgram: request.body?.captureProgram
      });
      return reply.code(201).send({ sessionId });
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.post("/api/capture-sessions/:sessionId/views", async (request, reply) => {
    try {
      const fields = {};
      let file;
      for await (const part of request.parts()) {
        if (part.type === "file") {
          file = {
            filename: part.filename,
            mimetype: part.mimetype,
            buffer: await part.toBuffer()
          };
        } else {
          fields[part.fieldname] = part.value;
        }
      }
      if (!file) throw new Error("One image file is required");
      const elevation = fields.elevation;
      if (!["low", "high", "zenith", "macro"].includes(elevation)) {
        throw new Error("elevation must be low, high, zenith, or macro");
      }
      const result = await captureService.addView({
        sessionId: integer(request.params.sessionId, "sessionId"),
        sequenceIndex: integer(fields.sequenceIndex, "sequenceIndex"),
        angleDeg: numberOrNull(fields.angleDeg),
        elevation,
        mmPerPixel: numberOrNull(fields.mmPerPixel),
        buffer: file.buffer,
        filename: file.filename
      });
      return reply.code(201).send(result);
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.post("/api/capture-sessions/:sessionId/process", async (request, reply) => {
    try {
      return await captureService.process(integer(request.params.sessionId, "sessionId"));
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.post("/api/simulate", async (request, reply) => {
    try {
      const trayId = integer(request.body?.trayId ?? repository.listTrays()[0]?.id, "trayId");
      const priorScans = repository.listSessions(100).filter((item) => item.tray_id === trayId).length;
      const capturedAt = request.body?.capturedAt
        ?? new Date(Date.now() + priorScans * 86_400_000).toISOString();
      return await simulateCapture({
        captureService,
        repository,
        trayId,
        seed: Number(request.body?.seed ?? 42 + priorScans),
        scanIndex: priorScans,
        capturedAt
      });
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.get("/api/alerts", async (request) => repository.listAlerts(request.query?.status ?? "open"));
  app.post("/api/alerts/:alertId/:action", async (request, reply) => {
    try {
      const action = request.params.action;
      if (!["acknowledge", "resolve"].includes(action)) {
        throw new Error("action must be acknowledge or resolve");
      }
      const alert = repository.updateAlert(
        integer(request.params.alertId, "alertId"),
        action,
        new Date().toISOString()
      );
      if (!alert) return reply.code(404).send({ error: "Alert not found" });
      return alert;
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.post("/api/findings/:findingId/reviews", async (request, reply) => {
    try {
      const body = request.body ?? {};
      if (!body.reviewer || !body.decision || !body.evidenceLevel) {
        throw new Error("reviewer, decision, and evidenceLevel are required");
      }
      const reviewId = repository.addReview({
        findingId: integer(request.params.findingId, "findingId"),
        reviewer: body.reviewer,
        decision: body.decision,
        diagnosis: body.diagnosis,
        evidenceLevel: body.evidenceLevel,
        notes: body.notes,
        createdAt: new Date().toISOString()
      });
      return reply.code(201).send({ reviewId });
    } catch (error) {
      return sendError(reply, error);
    }
  });

  app.setNotFoundHandler((request, reply) => {
    if (request.url.startsWith("/api/")) {
      return reply.code(404).send({ error: "API route not found" });
    }
    return reply.sendFile("index.html");
  });

  app.addHook("onClose", async () => {
    db.close();
  });

  return app;
}
