function parseJson(value, fallback) {
  if (value == null) return fallback;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

export class Repository {
  constructor(db) {
    this.db = db;
  }

  listSpecies() {
    return this.db.prepare(`
      SELECT * FROM species
      ORDER BY priority_rank IS NULL, priority_rank, common_name
    `).all();
  }

  listCohorts() {
    return this.db.prepare(`
      SELECT c.*, s.scientific_name, s.scientific_name_alias, s.common_name,
             s.leaf_type, s.priority_rank
      FROM cohorts c JOIN species s ON s.id = c.species_id
      ORDER BY s.priority_rank IS NULL, s.priority_rank, c.name
    `).all();
  }

  listTrays() {
    return this.db.prepare(`
      SELECT t.*, c.name AS cohort_name, s.common_name, s.scientific_name,
             s.scientific_name_alias, s.leaf_type, s.priority_rank,
             (SELECT COUNT(*) FROM capture_sessions cs WHERE cs.tray_id = t.id) AS session_count
      FROM trays t
      JOIN cohorts c ON c.id = t.cohort_id
      JOIN species s ON s.id = c.species_id
      ORDER BY s.priority_rank IS NULL, s.priority_rank, t.tray_code
    `).all();
  }

  getTray(trayId) {
    return this.db.prepare(`
      SELECT t.*, c.name AS cohort_name, c.seed_lot, c.sowing_date, c.block_name, c.treatment,
             s.common_name, s.scientific_name, s.scientific_name_alias,
             s.leaf_type, s.priority_rank
      FROM trays t
      JOIN cohorts c ON c.id = t.cohort_id
      JOIN species s ON s.id = c.species_id
      WHERE t.id = ?
    `).get(trayId);
  }

  getSeedlings(trayId) {
    return this.db.prepare(`
      SELECT * FROM seedlings
      WHERE tray_id = ?
      ORDER BY row_index, column_index
    `).all(trayId);
  }

  createSession({ trayId, capturedAt, captureProgram }) {
    const result = this.db.prepare(`
      INSERT INTO capture_sessions (tray_id, captured_at, capture_program)
      VALUES (?, ?, ?)
    `).run(trayId, capturedAt, captureProgram ?? "orbit-25-v1");
    return Number(result.lastInsertRowid);
  }

  addView(view) {
    const result = this.db.prepare(`
      INSERT INTO views (
        session_id, sequence_index, angle_deg, elevation, image_path, mm_per_pixel
      ) VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      view.sessionId,
      view.sequenceIndex,
      view.angleDeg ?? null,
      view.elevation,
      view.imagePath,
      view.mmPerPixel ?? null
    );
    return Number(result.lastInsertRowid);
  }

  updateViewQc(viewId, qc) {
    this.db.prepare(`
      UPDATE views
      SET width = ?, height = ?, sharpness = ?, mean_luma = ?, clipped_fraction = ?,
          qc_status = ?, qc_reasons = ?
      WHERE id = ?
    `).run(
      qc.width,
      qc.height,
      qc.sharpness,
      qc.meanLuma,
      qc.clippedFraction,
      qc.pass ? "passed" : "failed",
      JSON.stringify(qc.reasons),
      viewId
    );
  }

  getSession(sessionId) {
    return this.db.prepare(`
      SELECT cs.*, t.tray_code, t.rows, t.columns, t.width_mm, t.depth_mm,
             c.name AS cohort_name, s.common_name, s.scientific_name,
             s.scientific_name_alias, s.leaf_type, s.priority_rank
      FROM capture_sessions cs
      JOIN trays t ON t.id = cs.tray_id
      JOIN cohorts c ON c.id = t.cohort_id
      JOIN species s ON s.id = c.species_id
      WHERE cs.id = ?
    `).get(sessionId);
  }

  getViews(sessionId) {
    return this.db.prepare(`
      SELECT * FROM views WHERE session_id = ? ORDER BY sequence_index
    `).all(sessionId).map((view) => ({
      ...view,
      qc_reasons: parseJson(view.qc_reasons, [])
    }));
  }

  updateSession(sessionId, values) {
    this.db.prepare(`
      UPDATE capture_sessions
      SET status = ?, qc_pass_rate = ?, processed_at = ?, model_version = ?
      WHERE id = ?
    `).run(
      values.status,
      values.qcPassRate ?? null,
      values.processedAt ?? null,
      values.modelVersion ?? null,
      sessionId
    );
  }

  clearAnalysis(sessionId) {
    this.db.exec("BEGIN");
    try {
      this.db.prepare("DELETE FROM alerts WHERE session_id = ?").run(sessionId);
      this.db.prepare("DELETE FROM findings WHERE session_id = ?").run(sessionId);
      this.db.prepare("DELETE FROM observations WHERE session_id = ?").run(sessionId);
      this.db.exec("COMMIT");
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }

  addObservation(observation) {
    this.db.prepare(`
      INSERT INTO observations (
        session_id, seedling_id, metric, value, unit, uncertainty, coverage, model_version
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(session_id, seedling_id, metric) DO UPDATE SET
        value = excluded.value,
        unit = excluded.unit,
        uncertainty = excluded.uncertainty,
        coverage = excluded.coverage,
        model_version = excluded.model_version
    `).run(
      observation.sessionId,
      observation.seedlingId,
      observation.metric,
      observation.value,
      observation.unit,
      observation.uncertainty ?? null,
      observation.coverage ?? null,
      observation.modelVersion
    );
  }

  addFinding(finding) {
    const result = this.db.prepare(`
      INSERT INTO findings (
        session_id, seedling_id, category, syndrome, suspected_class,
        severity, confidence, evidence_level, details
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      finding.sessionId,
      finding.seedlingId ?? null,
      finding.category,
      finding.syndrome,
      finding.suspectedClass ?? null,
      finding.severity,
      finding.confidence,
      finding.evidenceLevel ?? "screening_only",
      JSON.stringify(finding.details ?? {})
    );
    return Number(result.lastInsertRowid);
  }

  addAlert(alert) {
    const result = this.db.prepare(`
      INSERT INTO alerts (finding_id, session_id, severity, message, created_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      alert.findingId ?? null,
      alert.sessionId,
      alert.severity,
      alert.message,
      alert.createdAt
    );
    return Number(result.lastInsertRowid);
  }

  listSessions(limit = 20) {
    return this.db.prepare(`
      SELECT cs.*, t.tray_code, s.common_name, s.scientific_name,
             s.scientific_name_alias, s.leaf_type, s.priority_rank,
             (SELECT COUNT(*) FROM findings f WHERE f.session_id = cs.id) AS finding_count,
             (SELECT COUNT(*) FROM alerts a WHERE a.session_id = cs.id AND a.status = 'open') AS open_alert_count
      FROM capture_sessions cs
      JOIN trays t ON t.id = cs.tray_id
      JOIN cohorts c ON c.id = t.cohort_id
      JOIN species s ON s.id = c.species_id
      ORDER BY s.priority_rank IS NULL, s.priority_rank, cs.captured_at DESC, cs.id DESC
      LIMIT ?
    `).all(limit);
  }

  getSessionDetail(sessionId) {
    const session = this.getSession(sessionId);
    if (!session) return null;
    const observations = this.db.prepare(`
      SELECT o.*, sd.row_index, sd.column_index
      FROM observations o JOIN seedlings sd ON sd.id = o.seedling_id
      WHERE o.session_id = ?
      ORDER BY sd.row_index, sd.column_index, o.metric
    `).all(sessionId);
    const findings = this.db.prepare(`
      SELECT f.*, sd.row_index, sd.column_index
      FROM findings f
      LEFT JOIN seedlings sd ON sd.id = f.seedling_id
      WHERE f.session_id = ?
      ORDER BY f.severity DESC, f.id
    `).all(sessionId).map((finding) => ({
      ...finding,
      details: parseJson(finding.details, {})
    }));
    return {
      ...session,
      views: this.getViews(sessionId),
      observations,
      findings
    };
  }

  getPreviousObservation(seedlingId, metric, beforeSessionId) {
    return this.db.prepare(`
      SELECT o.*, cs.captured_at
      FROM observations o
      JOIN capture_sessions cs ON cs.id = o.session_id
      WHERE o.seedling_id = ? AND o.metric = ? AND o.session_id != ?
        AND cs.status = 'processed'
      ORDER BY cs.captured_at DESC, o.id DESC
      LIMIT 1
    `).get(seedlingId, metric, beforeSessionId);
  }

  listAlerts(status = "open") {
    const where = status === "all" ? "" : "WHERE a.status = ?";
    const params = status === "all" ? [] : [status];
    return this.db.prepare(`
      SELECT a.*, t.tray_code, sd.row_index, sd.column_index,
             f.syndrome, f.confidence, f.evidence_level,
             s.common_name, s.scientific_name, s.scientific_name_alias, s.priority_rank
      FROM alerts a
      JOIN capture_sessions cs ON cs.id = a.session_id
      JOIN trays t ON t.id = cs.tray_id
      JOIN cohorts c ON c.id = t.cohort_id
      JOIN species s ON s.id = c.species_id
      LEFT JOIN findings f ON f.id = a.finding_id
      LEFT JOIN seedlings sd ON sd.id = f.seedling_id
      ${where}
      ORDER BY CASE a.status WHEN 'open' THEN 0 WHEN 'acknowledged' THEN 1 ELSE 2 END,
               s.priority_rank IS NULL, s.priority_rank, a.severity DESC, a.created_at DESC
    `).all(...params);
  }

  updateAlert(alertId, action, timestamp) {
    if (action === "acknowledge") {
      this.db.prepare(`
        UPDATE alerts SET status = 'acknowledged', acknowledged_at = ?
        WHERE id = ? AND status = 'open'
      `).run(timestamp, alertId);
    } else if (action === "resolve") {
      this.db.prepare(`
        UPDATE alerts SET status = 'resolved', resolved_at = ?
        WHERE id = ?
      `).run(timestamp, alertId);
    }
    return this.db.prepare("SELECT * FROM alerts WHERE id = ?").get(alertId);
  }

  addReview(review) {
    this.db.exec("BEGIN");
    try {
      const result = this.db.prepare(`
        INSERT INTO reviews (
          finding_id, reviewer, decision, diagnosis, evidence_level, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(
        review.findingId,
        review.reviewer,
        review.decision,
        review.diagnosis ?? null,
        review.evidenceLevel,
        review.notes ?? null,
        review.createdAt
      );
      this.db.prepare(`
        UPDATE findings
        SET review_status = ?, suspected_class = COALESCE(?, suspected_class),
            evidence_level = ?
        WHERE id = ?
      `).run(review.decision, review.diagnosis ?? null, review.evidenceLevel, review.findingId);
      this.db.exec("COMMIT");
      return Number(result.lastInsertRowid);
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }

  getDashboard() {
    const trays = this.db.prepare("SELECT COUNT(*) AS count FROM trays").get().count;
    const sessions = this.db.prepare("SELECT COUNT(*) AS count FROM capture_sessions").get().count;
    const processed = this.db.prepare(
      "SELECT COUNT(*) AS count FROM capture_sessions WHERE status = 'processed'"
    ).get().count;
    const openAlerts = this.db.prepare(
      "SELECT COUNT(*) AS count FROM alerts WHERE status = 'open'"
    ).get().count;
    const seedlings = this.db.prepare("SELECT COUNT(*) AS count FROM seedlings").get().count;
    const prioritySpecies = this.db.prepare(
      "SELECT COUNT(*) AS count FROM species WHERE priority_rank IS NOT NULL"
    ).get().count;
    const priorityTrays = this.db.prepare(`
      SELECT COUNT(*) AS count
      FROM trays t
      JOIN cohorts c ON c.id = t.cohort_id
      JOIN species s ON s.id = c.species_id
      WHERE s.priority_rank IS NOT NULL
    `).get().count;
    const prioritySeedlings = this.db.prepare(`
      SELECT COUNT(*) AS count
      FROM seedlings sd
      JOIN trays t ON t.id = sd.tray_id
      JOIN cohorts c ON c.id = t.cohort_id
      JOIN species s ON s.id = c.species_id
      WHERE s.priority_rank IS NOT NULL
    `).get().count;
    const latest = this.listSessions(8);
    return {
      trays,
      sessions,
      processed,
      openAlerts,
      seedlings,
      prioritySpecies,
      priorityTrays,
      prioritySeedlings,
      latest
    };
  }
}
