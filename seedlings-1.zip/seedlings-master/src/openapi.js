export const openApiDocument = {
  openapi: "3.1.0",
  info: {
    title: "Seedlings Vision MVP API",
    version: "0.1.0",
    description: "Node capture/control API with versioned Python ML inference and an explainable offline fallback for priority Idesia polycarpa and Japanese larch cohorts."
  },
  paths: {
    "/api/health": { get: { summary: "Service health and ML inference configuration" } },
    "/api/dashboard": { get: { summary: "Operator dashboard summary with priority cohort counts" } },
    "/api/species": { get: { summary: "List species in priority order with taxonomy metadata" } },
    "/api/cohorts": { get: { summary: "List cohorts in species-priority order" } },
    "/api/trays": { get: { summary: "List priority trays before historical trays" } },
    "/api/capture-sessions": {
      get: { summary: "List capture sessions" },
      post: { summary: "Create a capture session" }
    },
    "/api/capture-sessions/{sessionId}/views": {
      post: { summary: "Upload one view as multipart/form-data" }
    },
    "/api/capture-sessions/{sessionId}/process": {
      post: { summary: "Run QC and configured Python ML or baseline fallback analysis" }
    },
    "/api/simulate": { post: { summary: "Run a simulated 25-view scan" } },
    "/api/alerts": { get: { summary: "List alerts" } },
    "/api/alerts/{alertId}/{action}": {
      post: { summary: "Acknowledge or resolve an alert" }
    },
    "/api/findings/{findingId}/reviews": {
      post: { summary: "Submit expert review or lab confirmation" }
    }
  }
};
