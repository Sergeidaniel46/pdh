import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

const SCHEMA = `
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS species (
  id INTEGER PRIMARY KEY,
  scientific_name TEXT NOT NULL UNIQUE,
  common_name TEXT NOT NULL,
  leaf_type TEXT NOT NULL CHECK (leaf_type IN ('needle', 'broadleaf')),
  scientific_name_alias TEXT,
  priority_rank INTEGER
);

CREATE TABLE IF NOT EXISTS cohorts (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  species_id INTEGER NOT NULL REFERENCES species(id),
  seed_lot TEXT,
  sowing_date TEXT,
  block_name TEXT,
  treatment TEXT
);

CREATE TABLE IF NOT EXISTS trays (
  id INTEGER PRIMARY KEY,
  tray_code TEXT NOT NULL UNIQUE,
  cohort_id INTEGER NOT NULL REFERENCES cohorts(id),
  rows INTEGER NOT NULL CHECK (rows > 0),
  columns INTEGER NOT NULL CHECK (columns > 0),
  width_mm REAL NOT NULL DEFAULT 600,
  depth_mm REAL NOT NULL DEFAULT 400
);

CREATE TABLE IF NOT EXISTS seedlings (
  id INTEGER PRIMARY KEY,
  tray_id INTEGER NOT NULL REFERENCES trays(id) ON DELETE CASCADE,
  row_index INTEGER NOT NULL,
  column_index INTEGER NOT NULL,
  lifecycle_status TEXT NOT NULL DEFAULT 'active',
  UNIQUE(tray_id, row_index, column_index)
);

CREATE TABLE IF NOT EXISTS capture_sessions (
  id INTEGER PRIMARY KEY,
  tray_id INTEGER NOT NULL REFERENCES trays(id),
  captured_at TEXT NOT NULL,
  capture_program TEXT NOT NULL DEFAULT 'orbit-25-v1',
  status TEXT NOT NULL DEFAULT 'capturing',
  qc_pass_rate REAL,
  processed_at TEXT,
  model_version TEXT
);

CREATE TABLE IF NOT EXISTS views (
  id INTEGER PRIMARY KEY,
  session_id INTEGER NOT NULL REFERENCES capture_sessions(id) ON DELETE CASCADE,
  sequence_index INTEGER NOT NULL,
  angle_deg REAL,
  elevation TEXT NOT NULL CHECK (elevation IN ('low', 'high', 'zenith', 'macro')),
  image_path TEXT NOT NULL,
  mm_per_pixel REAL,
  width INTEGER,
  height INTEGER,
  sharpness REAL,
  mean_luma REAL,
  clipped_fraction REAL,
  qc_status TEXT NOT NULL DEFAULT 'pending',
  qc_reasons TEXT NOT NULL DEFAULT '[]',
  UNIQUE(session_id, sequence_index)
);

CREATE TABLE IF NOT EXISTS observations (
  id INTEGER PRIMARY KEY,
  session_id INTEGER NOT NULL REFERENCES capture_sessions(id) ON DELETE CASCADE,
  seedling_id INTEGER NOT NULL REFERENCES seedlings(id) ON DELETE CASCADE,
  metric TEXT NOT NULL,
  value REAL NOT NULL,
  unit TEXT NOT NULL,
  uncertainty REAL,
  coverage REAL,
  model_version TEXT NOT NULL,
  UNIQUE(session_id, seedling_id, metric)
);

CREATE TABLE IF NOT EXISTS findings (
  id INTEGER PRIMARY KEY,
  session_id INTEGER NOT NULL REFERENCES capture_sessions(id) ON DELETE CASCADE,
  seedling_id INTEGER REFERENCES seedlings(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  syndrome TEXT NOT NULL,
  suspected_class TEXT,
  severity INTEGER NOT NULL CHECK (severity BETWEEN 0 AND 4),
  confidence REAL NOT NULL,
  evidence_level TEXT NOT NULL DEFAULT 'screening_only',
  review_status TEXT NOT NULL DEFAULT 'pending',
  details TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY,
  finding_id INTEGER REFERENCES findings(id) ON DELETE CASCADE,
  session_id INTEGER NOT NULL REFERENCES capture_sessions(id) ON DELETE CASCADE,
  severity INTEGER NOT NULL,
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL,
  acknowledged_at TEXT,
  resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY,
  finding_id INTEGER NOT NULL REFERENCES findings(id) ON DELETE CASCADE,
  reviewer TEXT NOT NULL,
  decision TEXT NOT NULL,
  diagnosis TEXT,
  evidence_level TEXT NOT NULL,
  notes TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_tray_time ON capture_sessions(tray_id, captured_at);
CREATE INDEX IF NOT EXISTS idx_observations_seedling_metric ON observations(seedling_id, metric);
CREATE INDEX IF NOT EXISTS idx_findings_session ON findings(session_id);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
`;

function migrateSpeciesMetadata(db) {
  const columns = new Set(
    db.prepare("PRAGMA table_info(species)").all().map((column) => column.name)
  );
  if (!columns.has("scientific_name_alias")) {
    db.exec("ALTER TABLE species ADD COLUMN scientific_name_alias TEXT");
  }
  if (!columns.has("priority_rank")) {
    db.exec("ALTER TABLE species ADD COLUMN priority_rank INTEGER");
  }
}

export function createDatabase(databasePath) {
  if (databasePath !== ":memory:") {
    fs.mkdirSync(path.dirname(databasePath), { recursive: true });
  }

  const db = new DatabaseSync(databasePath);
  db.exec(SCHEMA);
  migrateSpeciesMetadata(db);
  return db;
}

export function seedDemoData(db) {
  const insertSpecies = db.prepare(`
    INSERT INTO species (
      scientific_name, common_name, leaf_type, scientific_name_alias, priority_rank
    ) VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(scientific_name) DO UPDATE SET
      common_name = excluded.common_name,
      leaf_type = excluded.leaf_type,
      scientific_name_alias = excluded.scientific_name_alias,
      priority_rank = excluded.priority_rank
  `);
  insertSpecies.run("Idesia polycarpa", "Igiri tree", "broadleaf", null, 1);
  insertSpecies.run(
    "Larix kaempferi",
    "Japanese larch",
    "needle",
    "Larix leptolepis",
    2
  );

  const targets = [
    {
      scientificName: "Idesia polycarpa",
      cohortName: "Idesia pilot A",
      seedLot: "IDESIA-2026-A",
      sowingDate: "2026-04-08",
      trayCode: "IDESIA-A-001"
    },
    {
      scientificName: "Larix kaempferi",
      cohortName: "Larch pilot A",
      seedLot: "LARCH-2026-A",
      sowingDate: "2026-04-01",
      trayCode: "LARCH-A-001"
    }
  ];
  const findTray = db.prepare("SELECT id FROM trays WHERE tray_code = ?");
  const findCohort = db.prepare(`
    SELECT id FROM cohorts WHERE name = ? AND species_id = ?
    ORDER BY id LIMIT 1
  `);
  const insertCohort = db.prepare(`
    INSERT INTO cohorts (name, species_id, seed_lot, sowing_date, block_name, treatment)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  for (const target of targets) {
    if (findTray.get(target.trayCode)) continue;
    const species = db.prepare(
      "SELECT id FROM species WHERE scientific_name = ?"
    ).get(target.scientificName);
    const existingCohort = findCohort.get(target.cohortName, species.id);
    const cohortId = existingCohort?.id ?? Number(insertCohort.run(
      target.cohortName,
      species.id,
      target.seedLot,
      target.sowingDate,
      "Zone A",
      "standard"
    ).lastInsertRowid);
    createTray(db, {
      trayCode: target.trayCode,
      cohortId,
      rows: 3,
      columns: 4,
      widthMm: 600,
      depthMm: 400
    });
  }
}

export function createTray(db, tray) {
  db.exec("BEGIN");
  try {
    const result = db.prepare(`
      INSERT INTO trays (tray_code, cohort_id, rows, columns, width_mm, depth_mm)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      tray.trayCode,
      tray.cohortId,
      tray.rows,
      tray.columns,
      tray.widthMm ?? 600,
      tray.depthMm ?? 400
    );
    const trayId = Number(result.lastInsertRowid);
    const insertSeedling = db.prepare(`
      INSERT INTO seedlings (tray_id, row_index, column_index)
      VALUES (?, ?, ?)
    `);
    for (let row = 0; row < tray.rows; row += 1) {
      for (let column = 0; column < tray.columns; column += 1) {
        insertSeedling.run(trayId, row, column);
      }
    }
    db.exec("COMMIT");
    return trayId;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

export function closeDatabase(db) {
  db.close();
}
