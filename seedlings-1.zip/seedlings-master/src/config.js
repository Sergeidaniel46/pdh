import path from "node:path";

export function createConfig(overrides = {}) {
  const rootDir = overrides.rootDir ?? process.cwd();
  const dataDir = overrides.dataDir ?? path.join(rootDir, "data");
  const mlOverrides = overrides.ml ?? {};
  const inferenceMode = mlOverrides.mode ?? process.env.ML_INFERENCE_MODE ?? "fallback";
  const inferenceTimeoutMs = Number(
    mlOverrides.timeoutMs ?? process.env.ML_INFERENCE_TIMEOUT_MS ?? 10_000
  );
  if (!["fallback", "required"].includes(inferenceMode)) {
    throw new Error("ML_INFERENCE_MODE must be fallback or required");
  }
  if (!Number.isFinite(inferenceTimeoutMs) || inferenceTimeoutMs <= 0) {
    throw new Error("ML_INFERENCE_TIMEOUT_MS must be a positive number");
  }

  return {
    rootDir,
    dataDir,
    databasePath: overrides.databasePath ?? path.join(dataDir, "seedlings.sqlite"),
    imageDir: overrides.imageDir ?? path.join(dataDir, "images"),
    publicDir: overrides.publicDir ?? path.join(rootDir, "public"),
    host: overrides.host ?? process.env.HOST ?? "127.0.0.1",
    port: Number(overrides.port ?? process.env.PORT ?? 3100),
    logger: overrides.logger ?? process.env.NODE_ENV !== "test",
    qc: {
      minimumWidth: 640,
      minimumHeight: 480,
      minimumLuma: 25,
      maximumLuma: 235,
      maximumClippedFraction: 0.25,
      minimumSharpness: 4,
      ...(overrides.qc ?? {})
    },
    modelVersion: "baseline-rgb-v1",
    ml: {
      url: mlOverrides.url ?? process.env.ML_INFERENCE_URL ?? null,
      mode: inferenceMode,
      timeoutMs: inferenceTimeoutMs
    }
  };
}
