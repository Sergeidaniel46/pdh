const elements = {
  prioritySpecies: document.querySelector("#priority-species"),
  summary: document.querySelector("#summary"),
  sessionsBody: document.querySelector("#sessions-body"),
  alertsList: document.querySelector("#alerts-list"),
  alertCount: document.querySelector("#alert-count"),
  traySelect: document.querySelector("#tray-select"),
  scanForm: document.querySelector("#scan-form"),
  scanStatus: document.querySelector("#scan-status"),
  refreshButton: document.querySelector("#refresh-button"),
  detail: document.querySelector("#session-detail"),
  detailTitle: document.querySelector("#detail-title"),
  detailMeta: document.querySelector("#detail-meta"),
  cellGrid: document.querySelector("#cell-grid")
};

async function api(path, options) {
  const response = await fetch(path, {
    headers: { "content-type": "application/json", ...(options?.headers ?? {}) },
    ...options
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error ?? `Request failed: ${response.status}`);
  return data;
}

function percent(value) {
  return value == null ? "—" : `${Math.round(value * 100)}%`;
}

function speciesIllustration(leafType) {
  if (leafType === "needle") {
    return `
      <svg viewBox="0 0 180 120" role="img" aria-label="Japanese larch seedling">
        <path class="trunk" d="M91 111 C90 79 94 46 88 10"/>
        <g class="needles">
          <path d="M90 30 L55 46 M90 30 L127 42 M92 51 L42 67 M92 51 L141 64 M91 74 L35 89 M91 74 L147 88"/>
          <path d="M64 42 l-11 -10 M64 42 l-16 1 M64 42 l-7 12 M118 39 l9 -12 M118 39 l16 -2 M118 39 l8 11"/>
          <path d="M55 63 l-13 -12 M55 63 l-17 2 M55 63 l-8 14 M130 60 l10 -12 M130 60 l18 2 M130 60 l7 14"/>
          <path d="M48 85 l-12 -12 M48 85 l-17 3 M48 85 l-6 13 M136 84 l10 -13 M136 84 l17 3 M136 84 l6 13"/>
        </g>
      </svg>
    `;
  }
  return `
    <svg viewBox="0 0 180 120" role="img" aria-label="Igiri tree seedling">
      <path class="trunk" d="M89 112 C93 79 87 49 92 14"/>
      <g class="leaves">
        <path d="M89 32 C70 12 42 24 49 47 C55 65 76 69 89 83 C102 68 126 62 132 43 C138 20 108 12 91 32 Z"/>
        <path d="M75 68 C60 54 38 63 43 80 C48 94 64 96 75 108 C86 96 104 91 108 77 C113 60 89 54 76 68 Z"/>
      </g>
    </svg>
  `;
}

function renderPrioritySpecies(trays) {
  const species = [];
  const seen = new Set();
  for (const tray of trays.filter((item) => item.priority_rank != null)) {
    if (seen.has(tray.scientific_name)) continue;
    seen.add(tray.scientific_name);
    species.push(tray);
  }
  elements.prioritySpecies.innerHTML = species.map((item) => `
    <article class="species-card ${item.leaf_type}">
      <div class="species-art">${speciesIllustration(item.leaf_type)}</div>
      <div>
        <p class="eyebrow">Priority ${item.priority_rank} · ${item.leaf_type}</p>
        <h3>${item.common_name}</h3>
        <p class="scientific"><i>${item.scientific_name}</i>${item.scientific_name_alias ? ` <span>syn. <i>${item.scientific_name_alias}</i></span>` : ""}</p>
        <p>${item.leaf_type === "needle"
          ? "Deciduous conifer profile · structure-led growth evidence"
          : "Broadleaf profile · canopy and greenness evidence"}</p>
      </div>
    </article>
  `).join("");
}

function renderSummary(data) {
  const cards = [
    ["Priority seedlings", data.prioritySeedlings, `${data.seedlings} tracked across all cohorts`],
    ["Capture sessions", data.sessions, `${data.processed} processed`],
    ["Target species", data.prioritySpecies, `${data.priorityTrays} configured priority batches`],
    ["Open alerts", data.openAlerts, "Human review required"]
  ];
  elements.summary.innerHTML = cards.map(([label, value, note]) => `
    <article class="summary-card">
      <p class="eyebrow">${label}</p>
      <strong>${value}</strong>
      <span>${note}</span>
    </article>
  `).join("");
}

function renderSessions(sessions) {
  elements.sessionsBody.innerHTML = sessions.length === 0
    ? `<tr><td colspan="5" class="empty">Run the first simulated scan.</td></tr>`
    : sessions.map((session) => `
      <tr data-session-id="${session.id}">
        <td><strong>${session.tray_code}</strong><br><span class="muted">${new Date(session.captured_at).toLocaleString()}</span></td>
        <td><strong>${session.common_name}</strong><br><span class="muted"><i>${session.scientific_name}</i>${session.scientific_name_alias ? ` · syn. <i>${session.scientific_name_alias}</i>` : ""}</span></td>
        <td><span class="badge ${session.status.includes("failed") ? "failed" : ""}">${session.status}</span></td>
        <td>${percent(session.qc_pass_rate)}</td>
        <td>${session.finding_count}${session.open_alert_count ? ` · ${session.open_alert_count} open` : ""}</td>
      </tr>
    `).join("");
  for (const row of elements.sessionsBody.querySelectorAll("tr[data-session-id]")) {
    row.addEventListener("click", () => loadSession(row.dataset.sessionId));
  }
}

function renderAlerts(alerts) {
  elements.alertCount.textContent = alerts.length;
  elements.alertsList.innerHTML = alerts.length === 0
    ? `<div class="empty">No open alerts.</div>`
    : alerts.map((alert) => `
      <div class="alert-item">
        <strong>${alert.tray_code} · severity ${alert.severity}</strong>
        <p>${alert.common_name} · <i>${alert.scientific_name}</i><br>${alert.message}<br>${Math.round((alert.confidence ?? 0) * 100)}% screening confidence</p>
        <div class="alert-actions">
          <button data-alert="${alert.id}" data-action="acknowledge">Acknowledge</button>
          <button data-alert="${alert.id}" data-action="resolve">Resolve</button>
        </div>
      </div>
    `).join("");
  for (const button of elements.alertsList.querySelectorAll("button[data-alert]")) {
    button.addEventListener("click", async () => {
      await api(`/api/alerts/${button.dataset.alert}/${button.dataset.action}`, { method: "POST" });
      await refresh();
    });
  }
}

function observationsByCell(detail) {
  const cells = new Map();
  for (const observation of detail.observations) {
    const key = `${observation.row_index}:${observation.column_index}`;
    if (!cells.has(key)) cells.set(key, { observations: {}, findings: [] });
    cells.get(key).observations[observation.metric] = observation;
  }
  for (const finding of detail.findings) {
    const key = `${finding.row_index}:${finding.column_index}`;
    if (!cells.has(key)) cells.set(key, { observations: {}, findings: [] });
    cells.get(key).findings.push(finding);
  }
  return cells;
}

async function loadSession(sessionId) {
  const detail = await api(`/api/sessions/${sessionId}`);
  const cells = observationsByCell(detail);
  elements.detail.classList.remove("hidden");
  elements.detailTitle.textContent = `${detail.tray_code} · ${detail.common_name}`;
  const taxonomy = detail.scientific_name_alias
    ? `${detail.scientific_name} · syn. ${detail.scientific_name_alias}`
    : detail.scientific_name;
  elements.detailMeta.textContent = `${taxonomy} · ${detail.views.length} views · ${percent(detail.qc_pass_rate)} QC pass · ${detail.model_version ?? "not processed"}`;
  elements.cellGrid.style.gridTemplateColumns = `repeat(${detail.columns}, minmax(130px, 1fr))`;
  const html = [];
  for (let row = 0; row < detail.rows; row += 1) {
    for (let column = 0; column < detail.columns; column += 1) {
      const cell = cells.get(`${row}:${column}`) ?? { observations: {}, findings: [] };
      const mostSevere = Math.max(0, ...cell.findings.map((finding) => finding.severity));
      const tone = mostSevere >= 2 ? "critical" : mostSevere === 1 ? "warning" : "";
      const height = cell.observations.height?.value;
      const coverage = cell.observations.view_coverage?.value;
      const green = cell.observations.green_fraction?.value;
      html.push(`
        <div class="cell ${tone}">
          <b>Cell ${row + 1}:${column + 1}</b>
          <div class="metrics">
            <span>Height<strong>${height == null ? "—" : `${height.toFixed(1)} mm`}</strong></span>
            <span>Coverage<strong>${percent(coverage)}</strong></span>
            <span>Green<strong>${percent(green)}</strong></span>
            <span>Findings<strong>${cell.findings.length}</strong></span>
          </div>
          ${cell.findings.map((finding) => `<div class="finding-label">${finding.syndrome.replaceAll("_", " ")}</div>`).join("")}
        </div>
      `);
    }
  }
  elements.cellGrid.innerHTML = html.join("");
  elements.detail.scrollIntoView({ behavior: "smooth", block: "start" });
}

async function refresh() {
  const [dashboard, alerts] = await Promise.all([
    api("/api/dashboard"),
    api("/api/alerts")
  ]);
  renderSummary(dashboard);
  renderSessions(dashboard.latest);
  renderAlerts(alerts);
}

async function initialize() {
  const trays = await api("/api/trays");
  const priorityTrays = trays.filter((tray) => tray.priority_rank != null);
  const otherTrays = trays.filter((tray) => tray.priority_rank == null);
  const optionsFor = (items) => items.map((tray) => `
    <option value="${tray.id}">${tray.tray_code} · ${tray.common_name}</option>
  `).join("");
  elements.traySelect.innerHTML = `
    <optgroup label="Priority species">${optionsFor(priorityTrays)}</optgroup>
    ${otherTrays.length ? `<optgroup label="Other / historical">${optionsFor(otherTrays)}</optgroup>` : ""}
  `;
  renderPrioritySpecies(trays);
  await refresh();
}

elements.scanForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = elements.scanForm.querySelector("button");
  button.disabled = true;
  elements.scanStatus.textContent = "Capturing 25 calibrated views and analyzing tray cells…";
  try {
    const result = await api("/api/simulate", {
      method: "POST",
      body: JSON.stringify({ trayId: Number(elements.traySelect.value) })
    });
    const engine = result.analysis.analysisEngine?.replaceAll("_", " ") ?? "analysis";
    elements.scanStatus.textContent = `Session ${result.sessionId} processed by ${engine} (${result.analysis.modelVersion}): ${result.analysis.findings} findings, ${result.analysis.alerts} alerts.`;
    await refresh();
    await loadSession(result.sessionId);
  } catch (error) {
    elements.scanStatus.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

elements.refreshButton.addEventListener("click", refresh);
initialize().catch((error) => {
  elements.scanStatus.textContent = `Unable to initialize: ${error.message}`;
});
